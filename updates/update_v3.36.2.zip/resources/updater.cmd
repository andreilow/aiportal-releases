@echo off
title AI Portal update
echo.
echo   Updating AI Portal - this takes a few seconds.
echo   The app reopens by itself when it's done.
echo.
rem v3.36 (security 2026-11-01) - the update runs in Windows PowerShell, not through "AI Portal.exe" in run-as-Node
rem mode (that switch let any script run through our exe; the fuse is off now). ONE line on purpose: the update
rem replaces this file while cmd waits, and cmd reads a batch file line by line.
powershell.exe -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%~dp0updater.ps1" & exit /b 0
