# AI Portal self-updater (v3.36 - security 2026-11-01). Started by updater.cmd (through the Task Scheduler, or
# directly) or by the app's PowerShell relay (AIP_APPDIR set). Replaces updater.js, which ran through
# "AI Portal.exe" in run-as-Node mode - a switch that also let anyone run their own scripts through our exe.
# Same flow as updater.js: lock + .alive handshake (the app quits only after seeing it), wait until app.asar can be
# moved aside (= Electron has exited) and the same for backend\, copy update_pending over the app dir, put BOTH
# halves back if the copy fails, clean up, relaunch. Log: %TEMP%\aiportal_updater.log.
# Keep this file pure ASCII (powershell.exe reads BOM-less files as ANSI). Every path goes through -LiteralPath or
# .NET, never through wildcard parsing. PowerShell reads the whole script before running it, so the update may
# replace this file while it runs.

$ErrorActionPreference = 'Continue'
$resDir = $PSScriptRoot
$appDir = $env:AIP_APPDIR
if (-not $appDir) { $appDir = Split-Path -Parent $resDir }
$pending = Join-Path $appDir 'update_pending'
$logPath = Join-Path $env:TEMP 'aiportal_updater.log'
$testRun = ($env:AIP_UPDATER_TEST -eq '1')   # the tests: no relaunch, no scheduled task

function Log([string]$m) {
    try { Add-Content -LiteralPath $logPath -Value ('[' + (Get-Date).ToUniversalTime().ToString('o') + '] [updater.ps1] ' + $m) } catch {}
}

function Move-Any([string]$from, [string]$to) {
    if ((Get-Item -LiteralPath $from -Force).PSIsContainer) { [System.IO.Directory]::Move($from, $to) }
    else { [System.IO.File]::Move($from, $to) }
}

function Remove-Any([string]$p) {
    if (Test-Path -LiteralPath $p) { Remove-Item -LiteralPath $p -Recurse -Force -ErrorAction Stop }
}

function Relaunch {
    if ($testRun) { Log 'relaunch skipped (test run)'; return }
    Remove-Item Env:ELECTRON_RUN_AS_NODE -ErrorAction SilentlyContinue   # must never reach the app
    Remove-Item Env:ELECTRON_NO_ASAR -ErrorAction SilentlyContinue
    $exe = Join-Path $appDir 'AI Portal.exe'
    try {
        $p = Start-Process -FilePath $exe -WorkingDirectory $appDir -PassThru
        Log ('relaunched ' + $exe + ' (pid ' + $p.Id + ')')
    } catch { Log ('RELAUNCH FAILED: ' + $_.Exception.Message) }
    # drop the scheduled task we may have been started from (best effort)
    try { Start-Process -FilePath 'schtasks.exe' -ArgumentList @('/Delete', '/TN', 'AIPortalUpdate', '/F') -WindowStyle Hidden } catch {}
}

# an interrupted earlier run may have left only $to (the previous version) - never delete it when $from is gone
function Move-Aside([string]$from, [string]$to, [int]$tries, [string]$label) {
    if (-not (Test-Path -LiteralPath $from)) { Log ($label + ': nothing to move aside'); return 'absent' }
    for ($i = 0; $i -lt $tries; $i++) {
        try { Remove-Any $to } catch {}   # a stale leftover still busy - retry below
        try { Move-Any $from $to; return 'moved' } catch { Start-Sleep -Milliseconds 500 }
    }
    Log ($label + ': still locked after ' + $tries + ' tries')
    return 'locked'
}

$script:copied = 0
function Copy-Tree([string]$src, [string]$dst) {
    [void][System.IO.Directory]::CreateDirectory($dst)
    foreach ($e in @(Get-ChildItem -LiteralPath $src -Force -ErrorAction Stop)) {
        if ($e.Name -eq '.alive' -or $e.Name -eq '.updater_lock') { continue }
        $d = Join-Path $dst $e.Name
        # a leftover of the WRONG kind at the destination (e.g. a stray directory named app.asar) never survives
        if ((Test-Path -LiteralPath $d) -and ((Get-Item -LiteralPath $d -Force).PSIsContainer -ne $e.PSIsContainer)) {
            Remove-Item -LiteralPath $d -Recurse -Force -ErrorAction Stop
        }
        if ($e.PSIsContainer) { Copy-Tree $e.FullName $d }
        else { Copy-Item -LiteralPath $e.FullName -Destination $d -Force -ErrorAction Stop; $script:copied++ }
    }
}

Log ('start pid=' + $PID + ' ps=' + $PSVersionTable.PSVersion + ' app=' + $appDir)
if (-not (Test-Path -LiteralPath $pending)) { Log 'no update_pending - nothing to do'; exit 0 }

# single-instance guard (a lock older than 2 min is a dead updater)
$lock = Join-Path $pending '.updater_lock'
try {
    $fs = [System.IO.File]::Open($lock, [System.IO.FileMode]::CreateNew, [System.IO.FileAccess]::Write)
    $b = [System.Text.Encoding]::ASCII.GetBytes([string]$PID)
    $fs.Write($b, 0, $b.Length)
    $fs.Close()
} catch {
    try {
        $age = ((Get-Date) - (Get-Item -LiteralPath $lock -Force).LastWriteTime).TotalSeconds
        if ($age -lt 120) { Log 'another updater holds the lock - exit'; exit 0 }
        [System.IO.File]::WriteAllText($lock, [string]$PID)
    } catch {}
}
# handshake: the app waits for this before it quits
try { [System.IO.File]::WriteAllText((Join-Path $pending '.alive'), [string]$PID) } catch {}

$asar = Join-Path $resDir 'app.asar'
$asarOld = Join-Path $resDir 'app.asar.old'
$be = Join-Path $resDir 'backend'
$beOld = Join-Path $resDir 'backend.old'

# wait for the app (<= 2 min): app.asar moves only once Electron is gone
$asarMoved = Move-Aside $asar $asarOld 240 'app.asar'
if ($asarMoved -eq 'locked') { Log 'app never released app.asar - giving up (nothing changed)'; exit 0 }
Log 'app exited - applying update'
# the frozen backend may still be shutting down (<= 30 s)
$beMoved = ((Move-Aside $be $beOld 60 'backend') -eq 'moved')

try {
    Copy-Tree $pending $appDir
    Log ('copied ' + $script:copied + ' files from update_pending over the app dir')
} catch {
    Log ('COPY FAILED: ' + $_.Exception.Message + ' - restoring the previous version')
    # restore BOTH halves unconditionally: a half-applied mix (new asar, old backend) is worse than the old version
    try { if ($asarMoved -eq 'moved' -and (Test-Path -LiteralPath $asarOld)) { Remove-Any $asar; Move-Any $asarOld $asar } } catch { Log ('asar restore failed: ' + $_.Exception.Message) }
    try { if ($beMoved -and (Test-Path -LiteralPath $beOld)) { Remove-Any $be; Move-Any $beOld $be } } catch { Log ('backend restore failed: ' + $_.Exception.Message) }
    Relaunch
    exit 0
}
# a zip that carries no backend must not leave the app without one
try { if ($beMoved -and -not (Test-Path -LiteralPath $be)) { Move-Any $beOld $be } } catch {}
foreach ($junk in @($pending, $asarOld, $beOld)) {
    try { Remove-Any $junk } catch { Log ('cleanup skipped: ' + $junk) }
}
Log 'update applied'
Relaunch
exit 0
