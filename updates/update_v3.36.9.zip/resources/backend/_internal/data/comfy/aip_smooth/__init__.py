# AI Portal — "Smooth motion" node pack for ComfyUI (ships with the app in
# data/comfy/aip_smooth; the app copies it into ComfyUI's custom_nodes).
#
# AIPSmoothRetime — Seedance takes judder: 24 fps, with the motion arriving in
# 4-frame pulses (the model's temporal compression — every fourth step jumps
# further, then the picture holds). This node
#   1. measures the motion each source interval carries (a small luma copy),
#   2. finds the CUTS (another shot: a huge, isolated jump) — they are never
#      interpolated (the morph of two unrelated frames) and never stretched,
#   3. re-times the frames so the motion is EVEN — an interval lasts as long as
#      the motion in it (the clip's length is kept) — the pulse disappears,
#   4. synthesises frames at the target rate (30 / 48 / 60 fps) with the loaded
#      RIFE / FILM model (ComfyUI's core FrameInterpolationModelLoader) at the
#      exact timesteps that even pace asks for; an output that lands on a
#      source frame keeps that frame (sharp, not synthesised),
#   5. calms the texture boil of AI footage with a motion-aware temporal blend
#      (a pixel that did not move between its neighbours is averaged with them;
#      a moving one is left alone).
# AIPDepthRig — a z-depth render of the frames (Depth Anything V2 Small, one
# grey scale for the whole clip): the MOTION RIG the Portal Swapper sends to
# Seedance instead of filmed people — the camera, the blocking and the body
# motion, no face, no scene.
#   scene "keep" (v3.35.1): only the PEOPLE become depth silhouettes — RT-DETR
#   v2 r18 finds them, SAM 2.1 tiny cuts them out, the silhouettes are grown and
#   feathered — and the room stays as filmed: Seedance edits the shot, rebuilding
#   the person from the references in the silhouette's place.
# AIPSaveVideo — writes the frames as H.264 MP4 at a chosen CRF (16 by default)
# with the source audio, the same on every ComfyUI core (the core's SaveVideo
# on older cores has no quality control and crushes a 720p take to ~2 Mbit/s).
# Classic node API (works on every ComfyUI that has the core interpolation
# nodes, 0.24 or newer). The pure helpers at module level have no ComfyUI
# dependency and are unit-tested on their own.
import math
import os
from pathlib import Path

import torch

VERSION = 11   # v11 (2026-11-08): the rig's blurs one axis at a time — same result, ~15-40x faster
SNAP = 0.06          # an output within 6 % of a source frame's time IS that frame


def motion_weights(images, max_w=256):
    """mean |ΔL| per consecutive pair of BHWC [0,1] frames, measured on a
    small luma copy — a (n-1,) float32 tensor (CPU)"""
    n = int(images.shape[0])
    if n < 2:
        return torch.zeros(0)
    w = int(images.shape[2])
    s = max(1, int(math.ceil(w / float(max_w))))
    out = []
    prev = None
    for i in range(n):
        f = images[i:i + 1].movedim(-1, 1).float()
        if s > 1:
            f = torch.nn.functional.avg_pool2d(f, s)
        l = 0.299 * f[:, 0] + 0.587 * f[:, 1] + 0.114 * f[:, 2]
        if prev is not None:
            out.append(float((l - prev).abs().mean().item()))
        prev = l
    return torch.tensor(out, dtype=torch.float32)


def detect_cuts(weights, thr=0.06, ratio=4.0, win=6):
    """the intervals that are a CUT (another shot), not motion: a mean |ΔL|
    above `thr` (luma 0..1; a whip pan on a Seedance take stays under ~0.04)
    that is also `ratio` × the median of the `win` intervals on either side —
    an isolated jump. A set of interval indexes."""
    n = int(weights.numel())
    cuts = set()
    if n == 0:
        return cuts
    w = weights.float()
    for k in range(n):
        v = float(w[k])
        if v < thr:
            continue
        lo, hi = max(0, k - win), min(n, k + win + 1)
        nb = torch.cat([w[lo:k], w[k + 1:hi]])
        med = float(nb.median()) if nb.numel() else 0.0
        if v >= ratio * max(med, 1e-4):
            cuts.add(k)
    return cuts


def time_map(weights, fps_in, equalize, floor_frac=0.35, cuts=None, local=12):
    """the start time (seconds) of every source frame: uniform (1 / fps_in),
    or ∝ the motion each interval carries. A cut splits the take into shots:
    the pace is evened INSIDE each shot and every shot keeps its own length
    (the cut stays where it was filmed), the cut interval itself is one plain
    source interval. A still interval keeps floor_frac of its shot's median so
    it never collapses. The clip keeps its length.
    v3.35.1 — in a shot longer than `local` intervals an interval is measured
    against the motion AROUND it (a moving average of `local` intervals, ×0.5–×2):
    the 4-frame burst/hold is a local alternation, and measuring against the
    whole shot squeezed still passages and stretched fast moves."""
    n = int(weights.numel()) + 1
    if n < 2:
        return [0.0]
    dt = 1.0 / float(fps_in)
    if not equalize:
        return [k * dt for k in range(n)]
    w = weights.clone().float()
    cuts = set(cuts or ())
    dur = [dt] * (n - 1)

    def even(a, b):
        m = b - a
        if m <= 0:
            return
        ws = w[a:b].clone()
        med = float(ws.median())
        floor = max(1e-4, med * floor_frac)
        ws = torch.clamp(ws, min=floor)
        if local and m > int(local):
            k = int(local)
            pad_l = k // 2
            base = torch.nn.functional.avg_pool1d(
                torch.nn.functional.pad(ws.view(1, 1, -1), (pad_l, k - 1 - pad_l), mode="replicate"), k, stride=1).view(-1)
            ws = torch.clamp(ws / torch.clamp(base, min=1e-6), 0.5, 2.0)
        ws = ws / float(ws.sum()) * (m * dt)
        for i in range(m):
            dur[a + i] = float(ws[i])

    a = 0
    for k in range(n - 1):
        if k in cuts:
            even(a, k)
            dur[k] = dt
            a = k + 1
    even(a, n - 1)
    t = [0.0]
    for k in range(n - 1):
        t.append(t[-1] + dur[k])
    t[-1] = (n - 1) * dt
    return t


def output_plan(starts, fps_out):
    """for every output frame at j / fps_out: (source pair k, u ∈ [0, 1] inside it)"""
    total = starts[-1]
    m = int(round(total * fps_out)) + 1
    plan = []
    k = 0
    last = len(starts) - 2
    for j in range(m):
        t = min(total, j / float(fps_out))
        while k < last and t >= starts[k + 1]:
            k += 1
        d = starts[k + 1] - starts[k]
        u = (t - starts[k]) / d if d > 0 else 0.0
        plan.append((k, min(1.0, max(0.0, u))))
    return plan


def calm_flicker(frames, strength, thr=0.045):
    """motion-aware temporal blend on BHWC frames (any device): a pixel that
    did not move between its neighbours is averaged with them (the texture
    boil of AI footage), a moving one is kept. strength 0..1."""
    n = int(frames.shape[0])
    if strength <= 0 or n < 3:
        return frames
    out = frames.clone()
    blur = torch.nn.AvgPool2d(5, stride=1, padding=2, count_include_pad=False)
    for j in range(1, n - 1):
        a, b, c = frames[j - 1].float(), frames[j].float(), frames[j + 1].float()
        nb = (a + c) * 0.5
        d = (b - nb).abs().mean(-1, keepdim=True)
        d = blur(d.movedim(-1, 0).unsqueeze(0)).squeeze(0).movedim(0, -1)
        m = torch.exp(-(d / thr) ** 2) * float(strength)
        out[j] = (b + (nb - b) * m).to(out.dtype)
    return out


class Mp4Writer:
    """v3.35.1 — a streaming H.264 writer: frames arrive chunk by chunk (a 4K clip never
    has to sit in memory whole); the audio stream is declared up front and muxed at
    close, trimmed to the frames written. The same encode as write_mp4."""

    def __init__(self, path, width, height, fps, audio=None, crf=16, preset="medium"):
        import av
        from fractions import Fraction
        self.av = av
        self.rate = Fraction(round(float(fps) * 1000), 1000)
        self.out = av.open(path, mode="w", format="mp4", options={"movflags": "faststart"})
        self.vs = self.out.add_stream("h264", rate=self.rate)
        self.vs.width = int(width)
        self.vs.height = int(height)
        self.vs.pix_fmt = "yuv420p"
        self.vs.options = {"crf": str(int(crf)), "preset": preset}
        self.n = 0
        self.wave = None
        self.a_stream = None
        self.sr = 0
        self.layout = "stereo"
        if audio and isinstance(audio, dict) and audio.get("waveform") is not None and int(audio.get("sample_rate") or 0) > 0:
            wave = audio["waveform"]
            if wave.dim() == 3:
                wave = wave[0]
            if wave.shape[1] > 0:
                self.sr = int(audio["sample_rate"])
                self.layout = {1: "mono", 2: "stereo", 6: "5.1"}.get(int(wave.shape[0]), "stereo")
                self.a_stream = self.out.add_stream("aac", rate=self.sr, layout=self.layout)
                self.wave = wave

    def add(self, images):
        for i in range(int(images.shape[0])):
            img = (images[i] * 255).clamp(0, 255).byte().cpu().numpy()
            fr = self.av.VideoFrame.from_ndarray(img, format="rgb24").reformat(format="yuv420p")
            self.out.mux(self.vs.encode(fr))
            self.n += 1

    def close(self):
        self.out.mux(self.vs.encode(None))
        if self.a_stream is not None and self.wave is not None:
            wave = self.wave[:, :int(math.ceil(self.sr / float(self.rate) * self.n))]
            if wave.shape[1] > 0:
                fr = self.av.AudioFrame.from_ndarray(wave.float().cpu().contiguous().numpy(), format="fltp", layout=self.layout)
                fr.sample_rate = self.sr
                fr.pts = 0
                self.out.mux(self.a_stream.encode(fr))
            self.out.mux(self.a_stream.encode(None))
        self.out.close()
        return self.n


def write_mp4(path, images, fps, audio=None, crf=16, preset="medium"):
    """BHWC [0,1] frames → an H.264 MP4 (yuv420p, libx264 at `crf`) with the
    ComfyUI AUDIO ({waveform (B, C, T), sample_rate}) as AAC, trimmed to the
    video's length. Returns the frame count written."""
    import av
    from fractions import Fraction
    n = int(images.shape[0])
    rate = Fraction(round(float(fps) * 1000), 1000)
    with av.open(path, mode="w", format="mp4", options={"movflags": "faststart"}) as out:
        vs = out.add_stream("h264", rate=rate)
        vs.width = int(images.shape[2])
        vs.height = int(images.shape[1])
        vs.pix_fmt = "yuv420p"
        vs.options = {"crf": str(int(crf)), "preset": preset}
        a_stream = None
        wave = None
        if audio and isinstance(audio, dict) and audio.get("waveform") is not None and int(audio.get("sample_rate") or 0) > 0:
            sr = int(audio["sample_rate"])
            wave = audio["waveform"]
            if wave.dim() == 3:
                wave = wave[0]
            wave = wave[:, :int(math.ceil(sr / float(rate) * n))]
            if wave.shape[1] > 0:
                layout = {1: "mono", 2: "stereo", 6: "5.1"}.get(int(wave.shape[0]), "stereo")
                a_stream = out.add_stream("aac", rate=sr, layout=layout)
            else:
                wave = None
        for i in range(n):
            img = (images[i] * 255).clamp(0, 255).byte().cpu().numpy()
            fr = av.VideoFrame.from_ndarray(img, format="rgb24").reformat(format="yuv420p")
            out.mux(vs.encode(fr))
        out.mux(vs.encode(None))
        if a_stream is not None and wave is not None:
            fr = av.AudioFrame.from_ndarray(wave.float().cpu().contiguous().numpy(), format="fltp", layout=layout)
            fr.sample_rate = sr
            fr.pts = 0
            out.mux(a_stream.encode(fr))
            out.mux(a_stream.encode(None))
    return n


class AIPSmoothRetime:
    @classmethod
    def INPUT_TYPES(cls):
        return {"required": {
            "interp_model": ("INTERP_MODEL",),
            "images": ("IMAGE",),
            "fps_in": ("FLOAT", {"default": 24.0, "min": 1.0, "max": 240.0, "step": 0.001}),
            "fps_out": ("FLOAT", {"default": 60.0, "min": 1.0, "max": 240.0, "step": 1.0}),
            "equalize": ("BOOLEAN", {"default": True}),
            "deflicker": ("FLOAT", {"default": 0.5, "min": 0.0, "max": 1.0, "step": 0.05}),
        }}

    RETURN_TYPES = ("IMAGE",)
    RETURN_NAMES = ("images",)
    FUNCTION = "run"
    CATEGORY = "AI Portal"
    DESCRIPTION = "Evens out the motion of an AI-generated take and raises its frame rate with the loaded RIFE / FILM model; cuts stay cuts."

    def run(self, interp_model, images, fps_in, fps_out, equalize, deflicker_strength=None, deflicker=0.5):
        import comfy.utils
        from comfy import model_management
        n = int(images.shape[0])
        if n < 2:
            return (images,)
        weights = motion_weights(images)
        cuts = detect_cuts(weights)
        starts = time_map(weights, float(fps_in), bool(equalize), cuts=cuts)
        plan = output_plan(starts, float(fps_out))
        device = interp_model.load_device
        dtype = interp_model.model_dtype()
        net = interp_model.model
        model_management.load_models_gpu([interp_model], memory_required=net.memory_used_forward(images.shape, dtype))
        align = getattr(net, "pad_align", 1)
        H, W = int(images.shape[1]), int(images.shape[2])
        # FILM computes its flow once per pair and synthesises a LIST of timesteps
        # on batch-1 inputs (its forward takes one scalar timestep per call, so a
        # batched timestep tensor breaks it); RIFE takes a batch of timesteps
        multi = getattr(net, "forward_multi_timestep", None)

        def prep(idx):
            f = images[idx:idx + 1].movedim(-1, 1).to(dtype=dtype, device=device)
            if align > 1:
                from comfy.ldm.common_dit import pad_to_patch_size
                f = pad_to_patch_size(f, (align, align), padding_mode="reflect")
            return f

        out_dtype = model_management.intermediate_dtype()
        off = model_management.intermediate_device()
        result = torch.empty((len(plan), 3, H, W), dtype=out_dtype, device=off)
        pbar = comfy.utils.ProgressBar(len(plan))
        batch = 8
        j = 0
        img0 = img1 = None
        f0 = f1 = None
        prev_k = -1
        while j < len(plan):
            k = plan[j][0]
            jj = j
            while jj < len(plan) and plan[jj][0] == k:
                jj += 1
            if k in cuts:
                # a cut: the nearer frame, never a blend of two shots
                for q in range(j, jj):
                    src = k if plan[q][1] < 0.5 else k + 1
                    result[q] = images[src].movedim(-1, 0).to(out_dtype)
                pbar.update(jj - j)
                j = jj
                continue
            if prev_k == k - 1 and img1 is not None:
                img0, f0 = img1, f1
            else:
                img0 = prep(k)
                f0 = net.extract_features(img0)
            img1 = prep(k + 1)
            f1 = net.extract_features(img1)
            prev_k = k
            mids = []     # (position, u) that need the model
            for q in range(j, jj):
                u = plan[q][1]
                if u <= SNAP:
                    result[q] = images[k].movedim(-1, 0).to(out_dtype)
                elif u >= 1 - SNAP:
                    result[q] = images[k + 1].movedim(-1, 0).to(out_dtype)
                else:
                    mids.append((q, u))
            i = 0
            while i < len(mids):
                b = min(batch, len(mids) - i)
                try:
                    if multi is not None:
                        outs = multi(img0, img1, [u for _, u in mids[i:i + b]], cache={"img0": f0, "img1": f1})
                    else:
                        ts = torch.tensor([u for _, u in mids[i:i + b]], device=device, dtype=dtype).reshape(b, 1, 1, 1)
                        ts = ts.expand(-1, 1, img0.shape[2], img0.shape[3])
                        outs = net(img0.expand(b, -1, -1, -1), img1.expand(b, -1, -1, -1), timestep=ts, cache={"img0": f0, "img1": f1})
                    for z in range(b):
                        result[mids[i + z][0]] = outs[z, :, :H, :W].to(out_dtype)
                    i += b
                except model_management.OOM_EXCEPTION:
                    if batch <= 1:
                        raise
                    batch = max(1, batch // 2)
                    model_management.soft_empty_cache()
            pbar.update(jj - j)
            j = jj
        frames = result.movedim(1, -1).clamp_(0.0, 1.0)
        strength = float(deflicker if deflicker_strength is None else deflicker_strength)
        if strength > 0:
            frames = calm_flicker(frames, strength)
        return (frames,)


# ── v3.35 · the depth MOTION RIG (the Portal Swapper's people route) ──
DEPTH_MODEL_DIR = "aip_depth/depth_anything_v2_small_hf"
MASK_DET_DIR = "aip_depth/rtdetr_v2_r18vd_hf"      # v3.35.1 — RT-DETR v2 r18 (Apache-2.0): where the people are
MASK_SEG_DIR = "aip_depth/sam2_1_hiera_tiny_hf"    # v3.35.1 — SAM 2.1 tiny (Apache-2.0): their exact silhouettes


def boxes_grow(boxes, H, W, frac=0.04):
    """v3.35.1 — detection boxes (xyxy) grown by frac of the frame's long side on every
    edge (hair, hands and a swinging coat lie outside a tight box), clamped to the frame."""
    g = float(frac) * max(int(H), int(W))
    out = []
    for b in boxes:
        x0, y0, x1, y1 = [float(v) for v in b]
        out.append([max(0.0, x0 - g), max(0.0, y0 - g), min(float(W), x1 + g), min(float(H), y1 + g)])
    return out


def hold_missing(masks, found):
    """v3.35.1 — masks (n, H, W); found[i] False = no person detected in frame i: that
    frame takes the previous detected frame's mask (the leading frames take the first
    detected one), so a detector miss never flashes the filmed person back for a frame."""
    n = int(masks.shape[0])
    last = None
    for i in range(n):
        if found[i]:
            last = i
        elif last is not None:
            masks[i] = masks[last]
    nxt = None
    for i in range(n - 1, -1, -1):
        if found[i]:
            nxt = i
        elif nxt is not None and not any(found[:i + 1]):
            masks[i] = masks[nxt]
    return masks


def mask_feather(masks, grow_frac=0.02, feather_px=3):
    """v3.35.1 — (n, H, W) masks 0..1 → grown by grow_frac of the frame height (a max
    filter: the silhouette covers the person fully, hair and all) and softened at the
    edge (a box blur of feather_px). The inside stays 1 — no filmed pixel of the person
    survives — and the edge melts into the room."""
    m = masks.float().unsqueeze(1)
    H = int(m.shape[-2])
    k = int(round(float(grow_frac) * H))
    if k > 0:   # pack v11 — max over the rectangle, one axis at a time (identical, O(k) instead of O(k²))
        m = torch.nn.functional.max_pool2d(m, kernel_size=(1, 2 * k + 1), stride=1, padding=(0, k))
        m = torch.nn.functional.max_pool2d(m, kernel_size=(2 * k + 1, 1), stride=1, padding=(k, 0))
    f = int(feather_px)
    if f > 0:   # pack v11 — the same box one axis at a time
        m = torch.nn.functional.avg_pool2d(m, kernel_size=(1, 2 * f + 1), stride=1, padding=(0, f), count_include_pad=False)
        m = torch.nn.functional.avg_pool2d(m, kernel_size=(2 * f + 1, 1), stride=1, padding=(f, 0), count_include_pad=False)
    return m[:, 0].clamp(0.0, 1.0)


def soften_depth(depth, frac):
    """v3.35.1 — (n, H, W) depth 0..1 blurred by a radius of frac × H (three box
    passes ≈ a Gaussian): the filmed person's hair edges, necklace, bow and dress
    outline melt away, the body pose, blocking and camera stay — Seedance keeps
    what a reference video SHOWS as geometry, and a motion rig must not show the look."""
    H = int(depth.shape[-2])
    r = int(round(float(frac) * H))
    if r <= 0:
        return depth
    x = depth.float().unsqueeze(1)
    k = 2 * r + 1
    for _ in range(3):   # pack v11 — the same box one axis at a time (a 2-D pass cost O(r²) per pixel on the CPU)
        x = torch.nn.functional.avg_pool2d(x, kernel_size=(1, k), stride=1, padding=(0, r), count_include_pad=False)
        x = torch.nn.functional.avg_pool2d(x, kernel_size=(k, 1), stride=1, padding=(r, 0), count_include_pad=False)
    return x[:, 0].clamp(0.0, 1.0).to(depth.dtype)


FACE_MODEL_DIR = "aip_depth/yunet"                    # v3.35.1 — YuNet (OpenCV zoo, Apache-2.0): where the faces are
FACE_MODEL_FILE = "face_detection_yunet_2023mar.onnx"


def face_boxes(frames_u8, model_path, score=0.6):
    """v3.35.1 — frames_u8: a list of (H, W, 3) RGB uint8 frames → per frame a list of
    [x0, y0, x1, y1] face boxes (YuNet through OpenCV's FaceDetectorYN). None when this
    OpenCV has no FaceDetectorYN (then: no face detail, the rig stays a plain blob)."""
    try:
        import cv2
        if not hasattr(cv2, "FaceDetectorYN"):
            return None
    except Exception:
        return None
    import numpy as np
    H, W = int(frames_u8[0].shape[0]), int(frames_u8[0].shape[1])
    det = cv2.FaceDetectorYN.create(str(model_path), "", (W, H), float(score), 0.3, 5000)
    out = []
    for f in frames_u8:
        _, faces = det.detect(np.ascontiguousarray(f[:, :, ::-1]))
        boxes = []
        if faces is not None:
            for r in faces:
                x, y, w, h = [float(v) for v in r[:4]]
                boxes.append([max(0.0, x), max(0.0, y), min(float(W), x + w), min(float(H), y + h)])
        out.append(boxes)
    return out


def face_region_mask(boxes_per_frame, H, W, grow=0.35, feather_frac=0.02):
    """v3.35.1 — per-frame face boxes → ((n, H, W) soft masks, found): each box grown by
    `grow` of its own size (more above it: the hair line), filled, feathered by
    feather_frac × H; a frame without a face takes the nearest frame's (hold_missing)."""
    n = len(boxes_per_frame)
    m = torch.zeros((n, int(H), int(W)), dtype=torch.float32)
    found = [False] * n
    for i, boxes in enumerate(boxes_per_frame):
        for x0, y0, x1, y1 in boxes or []:
            gw, gh = (x1 - x0) * float(grow), (y1 - y0) * float(grow)
            a, b = max(0, int(x0 - gw)), max(0, int(y0 - gh * 1.4))
            c, d = min(int(W), int(x1 + gw)), min(int(H), int(y1 + gh))
            if c > a and d > b:
                m[i, b:d, a:c] = 1.0
                found[i] = True
    if not any(found):
        return m, found
    m = hold_missing(m, found)
    return mask_feather(m, 0.0, int(round(float(feather_frac) * int(H)))), found


def composite_rig(frames, depth, masks):
    """v3.35.1 — frames (n, H, W, 3) 0..1, depth (n, H, W) 0..1 grey, masks (n, H, W) 0..1
    → the frame where the mask is 0, the depth grey where it is 1: the people become the
    rig, the room stays as filmed."""
    m = masks.to(frames.dtype).unsqueeze(-1)
    d = depth.to(frames.dtype).unsqueeze(-1).expand(-1, -1, -1, 3)
    return frames * (1.0 - m) + d * m


def person_masks(frames_u8, det_dir, seg_dir, device, threshold=0.2, grow=0.04, progress=None):
    """v3.35.1 — frames_u8: a list of (H, W, 3) uint8 numpy frames → (masks (n, H, W)
    float32 on the CPU, found [bool]). RT-DETR finds the people in each frame, SAM 2
    cuts each one out from its (grown) box, the cut-outs are unioned per frame. The
    detector threshold is LOW (0.2): a person cut by the frame (no head — a model's
    gown, a passer-by) scores ~0.3, and a missed person means filmed skin reaches
    Seedance; a false positive only turns a bit of the room grey. No ComfyUI
    dependency (testable on its own)."""
    from transformers import AutoImageProcessor, AutoModelForObjectDetection, Sam2Model, Sam2Processor
    det_p = AutoImageProcessor.from_pretrained(str(det_dir))
    det = AutoModelForObjectDetection.from_pretrained(str(det_dir)).to(device).eval()
    person_ids = {int(k) for k, v in det.config.id2label.items() if str(v).lower() == "person"} or {0}
    seg_p = Sam2Processor.from_pretrained(str(seg_dir))
    seg = Sam2Model.from_pretrained(str(seg_dir)).to(device).eval()
    n = len(frames_u8)
    H, W = int(frames_u8[0].shape[0]), int(frames_u8[0].shape[1])
    masks = torch.zeros((n, H, W), dtype=torch.float32)
    found = [False] * n
    B = 8
    with torch.no_grad():
        for i in range(0, n, B):
            chunk = list(frames_u8[i:i + B])
            inp = det_p(images=chunk, return_tensors="pt").to(device)
            out = det(**inp)
            res = det_p.post_process_object_detection(out, threshold=float(threshold), target_sizes=[(H, W)] * len(chunk))
            for j, r in enumerate(res):
                keep = [b.tolist() for b, l in zip(r["boxes"], r["labels"]) if int(l) in person_ids]
                keep = [b for b in keep if (b[2] - b[0]) * (b[3] - b[1]) >= 0.002 * H * W]
                if not keep:
                    continue
                boxes = boxes_grow(keep, H, W, grow)
                sin = seg_p(images=chunk[j], input_boxes=[boxes], return_tensors="pt").to(device)
                sout = seg(**sin, multimask_output=False)
                pm = seg_p.post_process_masks(sout.pred_masks.cpu(), sin["original_sizes"].cpu())[0]
                masks[i + j] = pm.reshape(-1, H, W).any(dim=0).float()
                found[i + j] = True
            if progress:
                progress(min(n, i + B))
    del det, seg
    return masks, found


def depth_normalize(maps, near_bright=True, lo_q=0.02, hi_q=0.98):
    """(N, h, w) relative inverse depth (any scale) → (N, h, w) float32 in 0..1
    with ONE scale for the whole clip (no flicker between frames): the 2nd..98th
    percentile of a sample of the values. near_bright: a near surface is white
    (Depth Anything predicts inverse depth), else black."""
    x = maps.float()
    flat = x.flatten()
    if flat.numel() > 2_000_000:
        flat = flat[torch.randint(0, flat.numel(), (2_000_000,))]
    lo = torch.quantile(flat, float(lo_q))
    hi = torch.quantile(flat, float(hi_q))
    if not bool(hi > lo):
        hi = lo + 1e-6
    y = ((x - lo) / (hi - lo)).clamp_(0.0, 1.0)
    return y if near_bright else 1.0 - y


def depth_inference_size(H, W, size=518):
    """the inference size: the short side = `size` (a multiple of 14, DINOv2's
    patch), the aspect kept → (h, w)"""
    s = max(14, int(size) // 14 * 14)
    if H <= W:
        return s, max(14, int(round(W / float(H) * s / 14.0)) * 14)
    return max(14, int(round(H / float(W) * s / 14.0)) * 14), s


def depth_maps(images, model_dir, size=518, near_bright=True):
    """v3.35.1 (pack v9) — (n, H, W, 3) frames 0..1 → (n, h, w) float32 depth 0..1 at the
    inference size (one scale for the whole clip): Depth Anything V2 Small through
    transformers, batched, halving the batch on OOM. Shared by AIPDepthRig and AIPRigProbe."""
    import comfy.utils
    import folder_paths
    from comfy import model_management
    try:
        from transformers import AutoModelForDepthEstimation
    except Exception as e:
        raise RuntimeError("this ComfyUI has no `transformers` package — update ComfyUI") from e
    d = Path(folder_paths.models_dir) / model_dir
    if not (d / "config.json").is_file() or not (d / "model.safetensors").is_file():
        raise RuntimeError(f"the depth model is not downloaded yet ({d})")
    device = model_management.get_torch_device()
    dtype = torch.float16 if device.type == "cuda" else torch.float32
    model = AutoModelForDepthEstimation.from_pretrained(str(d)).to(device=device, dtype=dtype).eval()
    n, H, W = int(images.shape[0]), int(images.shape[1]), int(images.shape[2])
    h, w = depth_inference_size(H, W, int(size))
    mean = torch.tensor([0.485, 0.456, 0.406], device=device, dtype=dtype).view(1, 3, 1, 1)
    std = torch.tensor([0.229, 0.224, 0.225], device=device, dtype=dtype).view(1, 3, 1, 1)
    maps = torch.empty((n, h, w), dtype=torch.float16)
    pbar = comfy.utils.ProgressBar(n)
    batch, i = 4, 0
    with torch.no_grad():
        while i < n:
            b = min(batch, n - i)
            try:
                x = images[i:i + b].movedim(-1, 1).to(device=device, dtype=dtype)
                x = torch.nn.functional.interpolate(x, size=(h, w), mode="bilinear", align_corners=False)
                x = (x - mean) / std
                out = model(pixel_values=x).predicted_depth
                if out.dim() == 4:
                    out = out[:, 0]
                if tuple(out.shape[-2:]) != (h, w):
                    out = torch.nn.functional.interpolate(out.unsqueeze(1), size=(h, w), mode="bilinear", align_corners=False)[:, 0]
                maps[i:i + b] = out.to("cpu", torch.float16)
                i += b
                pbar.update(b)
            except model_management.OOM_EXCEPTION:
                if batch <= 1:
                    raise
                batch = max(1, batch // 2)
                model_management.soft_empty_cache()
    del model
    model_management.soft_empty_cache()
    return depth_normalize(maps, bool(near_bright))


def probe_picks(n, k):
    """v3.35.1 (pack v9) — k frame indices spread over n frames, away from the very ends (the
    first and last frames are often a fade or a cut): the centres of k equal slices."""
    n, k = int(n), max(1, int(k))
    if n <= k:
        return list(range(max(0, n)))
    return sorted({min(n - 1, max(0, int(round((i + 0.5) * n / k - 0.5)))) for i in range(k)})


def pack_probe(frames, depth, pmask, fmask, preview_h=360):
    """v3.35.1 (pack v9) — frames (k, H, W, 3) 0..1, depth / people mask / face region (k, H, W)
    0..1 → one (1, k·h, 2·w, 3) sheet at preview height h: per row the filmed frame on the
    left and the packed maps on the right (R = depth, G = people, B = face), the rows top to
    bottom. The app draws the rig at any softness from this without another GPU pass."""
    k, H, W = int(depth.shape[0]), int(depth.shape[1]), int(depth.shape[2])
    h = max(2, int(preview_h) // 2 * 2)
    w = max(2, int(round(W * h / float(H))) // 2 * 2)
    aa = (h < H)
    fr = torch.nn.functional.interpolate(frames.float().movedim(-1, 1), size=(h, w), mode="bilinear", align_corners=False, antialias=aa).movedim(1, -1)
    maps = torch.stack([depth.float(), pmask.float(), fmask.float()], dim=1)
    mp = torch.nn.functional.interpolate(maps, size=(h, w), mode="bilinear", align_corners=False, antialias=aa).movedim(1, -1)
    rows = torch.cat([fr, mp], dim=2)
    return rows.reshape(1, k * h, 2 * w, 3).clamp(0.0, 1.0)


class AIPDepthRig:
    @classmethod
    def INPUT_TYPES(cls):
        return {"required": {
            "images": ("IMAGE",),
            "model_dir": ("STRING", {"default": DEPTH_MODEL_DIR}),
            "size": ("INT", {"default": 518, "min": 126, "max": 1036, "step": 14}),
            "near_bright": ("BOOLEAN", {"default": True}),
        }, "optional": {
            # v3.35.1 — scene keep: only the people become the rig, the room stays as filmed
            "scene": (["rebuild", "keep"], {"default": "rebuild"}),
            "det_dir": ("STRING", {"default": MASK_DET_DIR}),
            "seg_dir": ("STRING", {"default": MASK_SEG_DIR}),
            "grow": ("FLOAT", {"default": 0.02, "min": 0.0, "max": 0.2, "step": 0.005}),
            "feather": ("INT", {"default": 3, "min": 0, "max": 30}),
            # v3.35.1 — a soft rig: the depth blurred by this fraction of the frame height
            # (the keep-mask feather widens by the same), so no hair cut, jewellery or
            # garment outline of the filmed person reaches Seedance as geometry
            "soften": ("FLOAT", {"default": 0.0, "min": 0.0, "max": 0.1, "step": 0.005}),
            # v3.35.1 — the face keeps its motion: its depth is blurred only (1 - face_detail) as much
            "face_detail": ("FLOAT", {"default": 0.0, "min": 0.0, "max": 1.0, "step": 0.05}),
            "face_dir": ("STRING", {"default": FACE_MODEL_DIR}),
        }}

    RETURN_TYPES = ("IMAGE",)
    RETURN_NAMES = ("images",)
    FUNCTION = "run"
    CATEGORY = "AI Portal"
    DESCRIPTION = "A z-depth render of the frames (Depth Anything V2 Small, one scale for the clip): the motion rig the Portal Swapper sends instead of filmed people."

    def run(self, images, model_dir, size, near_bright, scene="rebuild", det_dir=MASK_DET_DIR, seg_dir=MASK_SEG_DIR, grow=0.02, feather=3, soften=0.0,
            face_detail=0.0, face_dir=FACE_MODEL_DIR):
        import comfy.utils
        import folder_paths
        from comfy import model_management
        n, H, W = int(images.shape[0]), int(images.shape[1]), int(images.shape[2])
        y = depth_maps(images, model_dir, int(size), bool(near_bright))   # v3.35.1 (pack v9) — shared with AIPRigProbe
        out_dtype = model_management.intermediate_dtype()
        # v3.35.1 — the faces: found once (YuNet) when the soft rig should keep their motion
        u8 = None
        fmask = None
        if float(soften) > 0 and float(face_detail) > 0:
            fp = Path(folder_paths.models_dir) / face_dir / FACE_MODEL_FILE
            if fp.is_file():
                u8 = [(images[j].clamp(0, 1) * 255).round().to(torch.uint8).cpu().numpy() for j in range(n)]
                fb = face_boxes(u8, fp)
                if fb is not None:
                    fm_, ff_ = face_region_mask(fb, H, W)
                    fmask = fm_ if any(ff_) else None
        frames = torch.empty((n, H, W, 3), dtype=out_dtype)
        for j in range(n):
            f = torch.nn.functional.interpolate(y[j:j + 1].unsqueeze(0), size=(H, W), mode="bilinear", align_corners=False)[0, 0]
            if float(soften) > 0:
                fs = soften_depth(f.unsqueeze(0), float(soften))[0]   # v3.35.1 — a soft rig
                if fmask is not None:
                    fl = soften_depth(f.unsqueeze(0), float(soften) * (1.0 - float(face_detail)))[0]
                    fm = fmask[j].to(fs.dtype)
                    f = fs * (1.0 - fm) + fl * fm
                else:
                    f = fs
            frames[j] = f.unsqueeze(-1).expand(H, W, 3).to(out_dtype)
        if str(scene) == "keep":
            # v3.35.1 — only the people become the rig: find them, cut them out, grow and
            # feather the silhouettes, lay the depth grey into them over the filmed frame
            dd, sd = Path(folder_paths.models_dir) / det_dir, Path(folder_paths.models_dir) / seg_dir
            for d_, what in ((dd, "people detector"), (sd, "people mask model")):
                if not (d_ / "config.json").is_file() or not (d_ / "model.safetensors").is_file():
                    raise RuntimeError(f"the {what} is not downloaded yet ({d_})")
            if u8 is None:
                u8 = [(images[j].clamp(0, 1) * 255).round().to(torch.uint8).cpu().numpy() for j in range(n)]
            pbar2 = comfy.utils.ProgressBar(n)
            masks, found = person_masks(u8, dd, sd, model_management.get_torch_device(), progress=lambda k: pbar2.update_absolute(k))   # v10 — the device is asked here (depth_maps keeps its own)
            model_management.soft_empty_cache()
            if not any(found):
                raise RuntimeError("no person found in the shot — Keep the scene masks people; use Rebuild the scene")
            masks = mask_feather(hold_missing(masks, found), float(grow), int(feather) + int(round(float(soften) * H)))   # v3.35.1 — a soft rig widens the feather
            frames = composite_rig(images.to(out_dtype).cpu(), frames[..., 0], masks).to(out_dtype)
        return (frames,)


class AIPRigProbe:
    """v3.35.1 (pack v9) — the Portal Swapper's DETAIL PREVIEW: a few frames of the shot traced
    once (depth, the people's silhouettes for scene keep, the face regions) and packed into one
    sheet (pack_probe), so the app can show the prepared shot at any Shape-detail setting
    without another GPU pass."""
    @classmethod
    def INPUT_TYPES(cls):
        return {"required": {
            "images": ("IMAGE",),
            "model_dir": ("STRING", {"default": DEPTH_MODEL_DIR}),
            "size": ("INT", {"default": 518, "min": 126, "max": 1036, "step": 14}),
            "near_bright": ("BOOLEAN", {"default": True}),
        }, "optional": {
            "scene": (["rebuild", "keep"], {"default": "rebuild"}),
            "det_dir": ("STRING", {"default": MASK_DET_DIR}),
            "seg_dir": ("STRING", {"default": MASK_SEG_DIR}),
            "face_dir": ("STRING", {"default": FACE_MODEL_DIR}),
            "picks": ("INT", {"default": 3, "min": 1, "max": 8}),
            "preview_h": ("INT", {"default": 360, "min": 90, "max": 1080, "step": 2}),
        }}

    RETURN_TYPES = ("IMAGE",)
    RETURN_NAMES = ("sheet",)
    FUNCTION = "run"
    CATEGORY = "AI Portal"
    DESCRIPTION = "A few frames of the clip traced once (depth, people, faces) into one packed sheet: the Portal Swapper's detail preview."

    def run(self, images, model_dir, size, near_bright, scene="rebuild", det_dir=MASK_DET_DIR, seg_dir=MASK_SEG_DIR, face_dir=FACE_MODEL_DIR,
            picks=3, preview_h=360):
        import folder_paths
        from comfy import model_management
        n = int(images.shape[0])
        idx = probe_picks(n, int(picks))
        sel = images[idx]
        k, H, W = int(sel.shape[0]), int(sel.shape[1]), int(sel.shape[2])
        y = depth_maps(sel, model_dir, int(size), bool(near_bright))
        depth = torch.nn.functional.interpolate(y.unsqueeze(1), size=(H, W), mode="bilinear", align_corners=False)[:, 0]
        u8 = [(sel[j].clamp(0, 1) * 255).round().to(torch.uint8).cpu().numpy() for j in range(k)]
        fmask = torch.zeros((k, H, W), dtype=torch.float32)
        fp = Path(folder_paths.models_dir) / face_dir / FACE_MODEL_FILE
        if fp.is_file():
            fb = face_boxes(u8, fp)
            if fb is not None:
                fm_, ff_ = face_region_mask(fb, H, W)
                if any(ff_):
                    fmask = fm_
        pmask = torch.zeros((k, H, W), dtype=torch.float32)
        if str(scene) == "keep":
            dd, sd = Path(folder_paths.models_dir) / det_dir, Path(folder_paths.models_dir) / seg_dir
            for d_, what in ((dd, "people detector"), (sd, "people mask model")):
                if not (d_ / "config.json").is_file() or not (d_ / "model.safetensors").is_file():
                    raise RuntimeError(f"the {what} is not downloaded yet ({d_})")
            masks, found = person_masks(u8, dd, sd, model_management.get_torch_device())
            model_management.soft_empty_cache()
            if any(found):
                pmask = hold_missing(masks, found)   # raw silhouettes: the app grows and feathers them per setting
        return (pack_probe(sel.float().cpu(), depth.float().cpu(), pmask, fmask, int(preview_h)),)


UPSCALE_TARGETS = {"1080p": (1920, 1080), "2k": (2560, 1440), "4k": (3840, 2160)}


def fit_target(H, W, target):
    """v3.35.1 — the output size for a size tier: the frame fitted inside the tier's box
    (3840×2160 for 4K, the box turned for a portrait frame), the aspect kept, both
    sides even, never smaller than the source. → (h, w)"""
    box = UPSCALE_TARGETS.get(str(target).lower(), UPSCALE_TARGETS["4k"])
    long_, short = max(box), min(box)
    bw, bh = (long_, short) if int(W) >= int(H) else (short, long_)
    sc = max(1.0, min(bw / float(W), bh / float(H)))
    return int(round(int(H) * sc / 2.0)) * 2, int(round(int(W) * sc / 2.0)) * 2


class AIPUpscaleVideo:
    @classmethod
    def INPUT_TYPES(cls):
        return {"required": {
            "images": ("IMAGE",),
            "upscale_model": ("UPSCALE_MODEL",),
            "fps": ("FLOAT", {"default": 24.0, "min": 1.0, "max": 240.0, "step": 0.001}),
            "target": (["1080p", "2k", "4k"], {"default": "4k"}),
            "deflicker": ("FLOAT", {"default": 0.3, "min": 0.0, "max": 1.0, "step": 0.05}),
            "filename_prefix": ("STRING", {"default": "aip_smooth/upscale"}),
            "crf": ("INT", {"default": 14, "min": 0, "max": 40}),
            "chunk": ("INT", {"default": 8, "min": 1, "max": 64}),
        }, "optional": {"audio": ("AUDIO",)}}

    RETURN_TYPES = ()
    FUNCTION = "run"
    OUTPUT_NODE = True
    CATEGORY = "AI Portal"
    DESCRIPTION = "The Fast local upscale: the upscale model on frame chunks (tiled), fitted to 1080p / 2K / 4K, the flicker calmed across chunk borders, written to an H.264 MP4 as it goes with the source audio."

    def run(self, images, upscale_model, fps, target, deflicker, filename_prefix, crf, chunk, audio=None):
        import comfy.utils
        import folder_paths
        from comfy import model_management
        n, H, W = int(images.shape[0]), int(images.shape[1]), int(images.shape[2])
        h, w = fit_target(H, W, target)
        full, fname, counter, sub, _ = folder_paths.get_save_image_path(
            filename_prefix, folder_paths.get_output_directory(), w, h)
        file = f"{fname}_{counter:05}_.mp4"
        device = model_management.get_torch_device()
        model_management.free_memory(model_management.module_size(upscale_model.model) + (512 * 512 * 3) * 4 * max(upscale_model.scale, 1.0) * 384.0, device)
        upscale_model.to(device)
        writer = Mp4Writer(os.path.join(full, file), w, h, float(fps), audio, int(crf))
        pbar = comfy.utils.ProgressBar(n)
        prev = None          # the previous chunk's last frame: the deflicker's context across the border
        tile, overlap = 512, 32
        step = max(1, int(chunk))
        try:
            for i in range(0, n, step):
                x = images[i:i + step].movedim(-1, 1).to(device)
                while True:
                    try:
                        y = comfy.utils.tiled_scale(x, lambda a: upscale_model(a.float()), tile_x=tile, tile_y=tile, overlap=overlap,
                                                    upscale_amount=upscale_model.scale, output_device=device)
                        break
                    except Exception as e:
                        model_management.raise_non_oom(e)
                        tile //= 2
                        if tile < 128:
                            raise
                y = torch.clamp(y, 0.0, 1.0)
                if tuple(y.shape[-2:]) != (h, w):
                    if int(y.shape[-2]) >= h:
                        y = torch.nn.functional.interpolate(y, size=(h, w), mode="area")
                    else:
                        y = torch.nn.functional.interpolate(y, size=(h, w), mode="bicubic", align_corners=False)
                y = y.movedim(1, -1).clamp(0.0, 1.0).to("cpu", torch.float32)
                if float(deflicker) > 0:
                    batch = y if prev is None else torch.cat([prev, y], dim=0)
                    batch = calm_flicker(batch, float(deflicker))
                    y = batch[1:] if prev is not None else batch
                prev = y[-1:].clone()
                writer.add(y)
                pbar.update(int(y.shape[0]))
                del x, y
        finally:
            upscale_model.to("cpu")
            model_management.soft_empty_cache()
        writer.close()
        return {"ui": {"images": [{"filename": file, "subfolder": sub, "type": "output"}], "animated": (True,)}}


class AIPSaveVideo:
    @classmethod
    def INPUT_TYPES(cls):
        return {"required": {
            "images": ("IMAGE",),
            "fps": ("FLOAT", {"default": 60.0, "min": 1.0, "max": 240.0, "step": 0.001}),
            "filename_prefix": ("STRING", {"default": "aip_smooth/smooth"}),
            "crf": ("INT", {"default": 16, "min": 0, "max": 40}),
        }, "optional": {"audio": ("AUDIO",)}}

    RETURN_TYPES = ()
    FUNCTION = "save"
    OUTPUT_NODE = True
    CATEGORY = "AI Portal"
    DESCRIPTION = "Writes the frames as an H.264 MP4 at the given CRF (16 = visually lossless) with the audio."

    def save(self, images, fps, filename_prefix, crf, audio=None):
        import folder_paths
        full, fname, counter, sub, _ = folder_paths.get_save_image_path(
            filename_prefix, folder_paths.get_output_directory(), int(images.shape[2]), int(images.shape[1]))
        file = f"{fname}_{counter:05}_.mp4"
        write_mp4(os.path.join(full, file), images, float(fps), audio, int(crf))
        return {"ui": {"images": [{"filename": file, "subfolder": sub, "type": "output"}], "animated": (True,)}}


NODE_CLASS_MAPPINGS = {"AIPSmoothRetime": AIPSmoothRetime, "AIPSaveVideo": AIPSaveVideo, "AIPDepthRig": AIPDepthRig,
                       "AIPUpscaleVideo": AIPUpscaleVideo, "AIPRigProbe": AIPRigProbe}
NODE_DISPLAY_NAME_MAPPINGS = {"AIPSmoothRetime": "AI Portal · Smooth motion (retime + interpolate)",
                              "AIPSaveVideo": "AI Portal · Save video (H.264, CRF)",
                              "AIPDepthRig": "AI Portal · Depth motion rig",
                              "AIPUpscaleVideo": "AI Portal · Upscale video (fast, streamed)",
                              "AIPRigProbe": "AI Portal · Rig detail preview (trace)"}
