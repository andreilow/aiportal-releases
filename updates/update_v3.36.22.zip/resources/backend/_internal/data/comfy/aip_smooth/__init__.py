# AI Portal — "Smooth motion" node pack for ComfyUI (ships with the app in
# data/comfy/aip_smooth; the app copies it into ComfyUI's custom_nodes).
#
# AIPSmoothRetime — Seedance takes judder: 24 fps, with the motion arriving in
# 4-frame pulses (the model's temporal compression — every fourth step jumps
# further, then the picture holds). This node
#   1. measures the motion each source interval carries (a small luma copy),
#   2. finds the CUTS (another shot: a huge, isolated jump) — they are never
#      interpolated (the morph of two unrelated frames) and never stretched,
#   3. re-times the frames so the motion is EVEN — an interval lasts as long as
#      the motion in it (the clip's length is kept) — the pulse disappears,
#   4. synthesises frames at the target rate (30 / 48 / 60 fps) with the loaded
#      RIFE / FILM model (ComfyUI's core FrameInterpolationModelLoader) at the
#      exact timesteps that even pace asks for; an output that lands on a
#      source frame keeps that frame (sharp, not synthesised),
#   5. calms the texture boil of AI footage with a motion-aware temporal blend
#      (a pixel that did not move between its neighbours is averaged with them;
#      a moving one is left alone).
# AIPDepthRig — a z-depth render of the frames (Depth Anything V2 Small, one
# grey scale for the whole clip): the MOTION RIG the Portal Swapper sends to
# Seedance instead of filmed people — the camera, the blocking and the body
# motion, no face, no scene.
#   scene "keep" (v3.35.1): only the PEOPLE become depth silhouettes — RT-DETR
#   v2 r18 finds them, SAM 2.1 tiny cuts them out, the silhouettes are grown and
#   feathered — and the room stays as filmed: Seedance edits the shot, rebuilding
#   the person from the references in the silhouette's place.
#   subject "vehicle" (v13, Motion only for cars): THE car of each shot becomes the
#   rig instead (duplicate boxes merged, the target's side, its convex hull, its
#   depth blurred relative to its own height) and the rest stays as filmed.
#   subject "both" (v14, Recast with People AND Cars in the shot): the car rig first
#   (as "vehicle", at the car's own softness and grow), then the people's rig laid
#   over it (their silhouettes, softness and face rule; where both are, the nearer
#   depth wins) — one prepared shot.
# AIPSaveVideo — writes the frames as H.264 MP4 at a chosen CRF (16 by default)
# with the source audio, the same on every ComfyUI core (the core's SaveVideo
# on older cores has no quality control and crushes a 720p take to ~2 Mbit/s).
# Classic node API (works on every ComfyUI that has the core interpolation
# nodes, 0.24 or newer). The pure helpers at module level have no ComfyUI
# dependency and are unit-tested on their own.
import math
import os
from pathlib import Path

import torch

VERSION = 14   # v14 (2026-11-21): the rig's subject "both" (Recast: people and cars). v13: subject "vehicle" (Motion only for cars). v12 is the Mac build's (MPS guards, another branch): a merge keeps all and a number above 14
# v11 (2026-11-08): the rig's blurs one axis at a time — same result, ~15-40x faster
SNAP = 0.06          # an output within 6 % of a source frame's time IS that frame


def motion_weights(images, max_w=256):
    """mean |ΔL| per consecutive pair of BHWC [0,1] frames, measured on a
    small luma copy — a (n-1,) float32 tensor (CPU)"""
    n = int(images.shape[0])
    if n < 2:
        return torch.zeros(0)
    w = int(images.shape[2])
    s = max(1, int(math.ceil(w / float(max_w))))
    out = []
    prev = None
    for i in range(n):
        f = images[i:i + 1].movedim(-1, 1).float()
        if s > 1:
            f = torch.nn.functional.avg_pool2d(f, s)
        l = 0.299 * f[:, 0] + 0.587 * f[:, 1] + 0.114 * f[:, 2]
        if prev is not None:
            out.append(float((l - prev).abs().mean().item()))
        prev = l
    return torch.tensor(out, dtype=torch.float32)


def detect_cuts(weights, thr=0.06, ratio=4.0, win=6):
    """the intervals that are a CUT (another shot), not motion: a mean |ΔL|
    above `thr` (luma 0..1; a whip pan on a Seedance take stays under ~0.04)
    that is also `ratio` × the median of the `win` intervals on either side —
    an isolated jump. A set of interval indexes."""
    n = int(weights.numel())
    cuts = set()
    if n == 0:
        return cuts
    w = weights.float()
    for k in range(n):
        v = float(w[k])
        if v < thr:
            continue
        lo, hi = max(0, k - win), min(n, k + win + 1)
        nb = torch.cat([w[lo:k], w[k + 1:hi]])
        med = float(nb.median()) if nb.numel() else 0.0
        if v >= ratio * max(med, 1e-4):
            cuts.add(k)
    return cuts


def time_map(weights, fps_in, equalize, floor_frac=0.35, cuts=None, local=12):
    """the start time (seconds) of every source frame: uniform (1 / fps_in),
    or ∝ the motion each interval carries. A cut splits the take into shots:
    the pace is evened INSIDE each shot and every shot keeps its own length
    (the cut stays where it was filmed), the cut interval itself is one plain
    source interval. A still interval keeps floor_frac of its shot's median so
    it never collapses. The clip keeps its length.
    v3.35.1 — in a shot longer than `local` intervals an interval is measured
    against the motion AROUND it (a moving average of `local` intervals, ×0.5–×2):
    the 4-frame burst/hold is a local alternation, and measuring against the
    whole shot squeezed still passages and stretched fast moves."""
    n = int(weights.numel()) + 1
    if n < 2:
        return [0.0]
    dt = 1.0 / float(fps_in)
    if not equalize:
        return [k * dt for k in range(n)]
    w = weights.clone().float()
    cuts = set(cuts or ())
    dur = [dt] * (n - 1)

    def even(a, b):
        m = b - a
        if m <= 0:
            return
        ws = w[a:b].clone()
        med = float(ws.median())
        floor = max(1e-4, med * floor_frac)
        ws = torch.clamp(ws, min=floor)
        if local and m > int(local):
            k = int(local)
            pad_l = k // 2
            base = torch.nn.functional.avg_pool1d(
                torch.nn.functional.pad(ws.view(1, 1, -1), (pad_l, k - 1 - pad_l), mode="replicate"), k, stride=1).view(-1)
            ws = torch.clamp(ws / torch.clamp(base, min=1e-6), 0.5, 2.0)
        ws = ws / float(ws.sum()) * (m * dt)
        for i in range(m):
            dur[a + i] = float(ws[i])

    a = 0
    for k in range(n - 1):
        if k in cuts:
            even(a, k)
            dur[k] = dt
            a = k + 1
    even(a, n - 1)
    t = [0.0]
    for k in range(n - 1):
        t.append(t[-1] + dur[k])
    t[-1] = (n - 1) * dt
    return t


def output_plan(starts, fps_out):
    """for every output frame at j / fps_out: (source pair k, u ∈ [0, 1] inside it)"""
    total = starts[-1]
    m = int(round(total * fps_out)) + 1
    plan = []
    k = 0
    last = len(starts) - 2
    for j in range(m):
        t = min(total, j / float(fps_out))
        while k < last and t >= starts[k + 1]:
            k += 1
        d = starts[k + 1] - starts[k]
        u = (t - starts[k]) / d if d > 0 else 0.0
        plan.append((k, min(1.0, max(0.0, u))))
    return plan


def calm_flicker(frames, strength, thr=0.045):
    """motion-aware temporal blend on BHWC frames (any device): a pixel that
    did not move between its neighbours is averaged with them (the texture
    boil of AI footage), a moving one is kept. strength 0..1."""
    n = int(frames.shape[0])
    if strength <= 0 or n < 3:
        return frames
    out = frames.clone()
    blur = torch.nn.AvgPool2d(5, stride=1, padding=2, count_include_pad=False)
    for j in range(1, n - 1):
        a, b, c = frames[j - 1].float(), frames[j].float(), frames[j + 1].float()
        nb = (a + c) * 0.5
        d = (b - nb).abs().mean(-1, keepdim=True)
        d = blur(d.movedim(-1, 0).unsqueeze(0)).squeeze(0).movedim(0, -1)
        m = torch.exp(-(d / thr) ** 2) * float(strength)
        out[j] = (b + (nb - b) * m).to(out.dtype)
    return out


class Mp4Writer:
    """v3.35.1 — a streaming H.264 writer: frames arrive chunk by chunk (a 4K clip never
    has to sit in memory whole); the audio stream is declared up front and muxed at
    close, trimmed to the frames written. The same encode as write_mp4."""

    def __init__(self, path, width, height, fps, audio=None, crf=16, preset="medium"):
        import av
        from fractions import Fraction
        self.av = av
        self.rate = Fraction(round(float(fps) * 1000), 1000)
        self.out = av.open(path, mode="w", format="mp4", options={"movflags": "faststart"})
        self.vs = self.out.add_stream("h264", rate=self.rate)
        self.vs.width = int(width)
        self.vs.height = int(height)
        self.vs.pix_fmt = "yuv420p"
        self.vs.options = {"crf": str(int(crf)), "preset": preset}
        self.n = 0
        self.wave = None
        self.a_stream = None
        self.sr = 0
        self.layout = "stereo"
        if audio and isinstance(audio, dict) and audio.get("waveform") is not None and int(audio.get("sample_rate") or 0) > 0:
            wave = audio["waveform"]
            if wave.dim() == 3:
                wave = wave[0]
            if wave.shape[1] > 0:
                self.sr = int(audio["sample_rate"])
                self.layout = {1: "mono", 2: "stereo", 6: "5.1"}.get(int(wave.shape[0]), "stereo")
                self.a_stream = self.out.add_stream("aac", rate=self.sr, layout=self.layout)
                self.wave = wave

    def add(self, images):
        for i in range(int(images.shape[0])):
            img = (images[i] * 255).clamp(0, 255).byte().cpu().numpy()
            fr = self.av.VideoFrame.from_ndarray(img, format="rgb24").reformat(format="yuv420p")
            self.out.mux(self.vs.encode(fr))
            self.n += 1

    def close(self):
        self.out.mux(self.vs.encode(None))
        if self.a_stream is not None and self.wave is not None:
            wave = self.wave[:, :int(math.ceil(self.sr / float(self.rate) * self.n))]
            if wave.shape[1] > 0:
                fr = self.av.AudioFrame.from_ndarray(wave.float().cpu().contiguous().numpy(), format="fltp", layout=self.layout)
                fr.sample_rate = self.sr
                fr.pts = 0
                self.out.mux(self.a_stream.encode(fr))
            self.out.mux(self.a_stream.encode(None))
        self.out.close()
        return self.n


def write_mp4(path, images, fps, audio=None, crf=16, preset="medium"):
    """BHWC [0,1] frames → an H.264 MP4 (yuv420p, libx264 at `crf`) with the
    ComfyUI AUDIO ({waveform (B, C, T), sample_rate}) as AAC, trimmed to the
    video's length. Returns the frame count written."""
    import av
    from fractions import Fraction
    n = int(images.shape[0])
    rate = Fraction(round(float(fps) * 1000), 1000)
    with av.open(path, mode="w", format="mp4", options={"movflags": "faststart"}) as out:
        vs = out.add_stream("h264", rate=rate)
        vs.width = int(images.shape[2])
        vs.height = int(images.shape[1])
        vs.pix_fmt = "yuv420p"
        vs.options = {"crf": str(int(crf)), "preset": preset}
        a_stream = None
        wave = None
        if audio and isinstance(audio, dict) and audio.get("waveform") is not None and int(audio.get("sample_rate") or 0) > 0:
            sr = int(audio["sample_rate"])
            wave = audio["waveform"]
            if wave.dim() == 3:
                wave = wave[0]
            wave = wave[:, :int(math.ceil(sr / float(rate) * n))]
            if wave.shape[1] > 0:
                layout = {1: "mono", 2: "stereo", 6: "5.1"}.get(int(wave.shape[0]), "stereo")
                a_stream = out.add_stream("aac", rate=sr, layout=layout)
            else:
                wave = None
        for i in range(n):
            img = (images[i] * 255).clamp(0, 255).byte().cpu().numpy()
            fr = av.VideoFrame.from_ndarray(img, format="rgb24").reformat(format="yuv420p")
            out.mux(vs.encode(fr))
        out.mux(vs.encode(None))
        if a_stream is not None and wave is not None:
            fr = av.AudioFrame.from_ndarray(wave.float().cpu().contiguous().numpy(), format="fltp", layout=layout)
            fr.sample_rate = sr
            fr.pts = 0
            out.mux(a_stream.encode(fr))
            out.mux(a_stream.encode(None))
    return n


class AIPSmoothRetime:
    @classmethod
    def INPUT_TYPES(cls):
        return {"required": {
            "interp_model": ("INTERP_MODEL",),
            "images": ("IMAGE",),
            "fps_in": ("FLOAT", {"default": 24.0, "min": 1.0, "max": 240.0, "step": 0.001}),
            "fps_out": ("FLOAT", {"default": 60.0, "min": 1.0, "max": 240.0, "step": 1.0}),
            "equalize": ("BOOLEAN", {"default": True}),
            "deflicker": ("FLOAT", {"default": 0.5, "min": 0.0, "max": 1.0, "step": 0.05}),
        }}

    RETURN_TYPES = ("IMAGE",)
    RETURN_NAMES = ("images",)
    FUNCTION = "run"
    CATEGORY = "AI Portal"
    DESCRIPTION = "Evens out the motion of an AI-generated take and raises its frame rate with the loaded RIFE / FILM model; cuts stay cuts."

    def run(self, interp_model, images, fps_in, fps_out, equalize, deflicker_strength=None, deflicker=0.5):
        import comfy.utils
        from comfy import model_management
        n = int(images.shape[0])
        if n < 2:
            return (images,)
        weights = motion_weights(images)
        cuts = detect_cuts(weights)
        starts = time_map(weights, float(fps_in), bool(equalize), cuts=cuts)
        plan = output_plan(starts, float(fps_out))
        device = interp_model.load_device
        dtype = interp_model.model_dtype()
        net = interp_model.model
        model_management.load_models_gpu([interp_model], memory_required=net.memory_used_forward(images.shape, dtype))
        align = getattr(net, "pad_align", 1)
        H, W = int(images.shape[1]), int(images.shape[2])
        # FILM computes its flow once per pair and synthesises a LIST of timesteps
        # on batch-1 inputs (its forward takes one scalar timestep per call, so a
        # batched timestep tensor breaks it); RIFE takes a batch of timesteps
        multi = getattr(net, "forward_multi_timestep", None)

        def prep(idx):
            f = images[idx:idx + 1].movedim(-1, 1).to(dtype=dtype, device=device)
            if align > 1:
                from comfy.ldm.common_dit import pad_to_patch_size
                f = pad_to_patch_size(f, (align, align), padding_mode="reflect")
            return f

        out_dtype = model_management.intermediate_dtype()
        off = model_management.intermediate_device()
        result = torch.empty((len(plan), 3, H, W), dtype=out_dtype, device=off)
        pbar = comfy.utils.ProgressBar(len(plan))
        batch = 8
        j = 0
        img0 = img1 = None
        f0 = f1 = None
        prev_k = -1
        while j < len(plan):
            k = plan[j][0]
            jj = j
            while jj < len(plan) and plan[jj][0] == k:
                jj += 1
            if k in cuts:
                # a cut: the nearer frame, never a blend of two shots
                for q in range(j, jj):
                    src = k if plan[q][1] < 0.5 else k + 1
                    result[q] = images[src].movedim(-1, 0).to(out_dtype)
                pbar.update(jj - j)
                j = jj
                continue
            if prev_k == k - 1 and img1 is not None:
                img0, f0 = img1, f1
            else:
                img0 = prep(k)
                f0 = net.extract_features(img0)
            img1 = prep(k + 1)
            f1 = net.extract_features(img1)
            prev_k = k
            mids = []     # (position, u) that need the model
            for q in range(j, jj):
                u = plan[q][1]
                if u <= SNAP:
                    result[q] = images[k].movedim(-1, 0).to(out_dtype)
                elif u >= 1 - SNAP:
                    result[q] = images[k + 1].movedim(-1, 0).to(out_dtype)
                else:
                    mids.append((q, u))
            i = 0
            while i < len(mids):
                b = min(batch, len(mids) - i)
                try:
                    if multi is not None:
                        outs = multi(img0, img1, [u for _, u in mids[i:i + b]], cache={"img0": f0, "img1": f1})
                    else:
                        ts = torch.tensor([u for _, u in mids[i:i + b]], device=device, dtype=dtype).reshape(b, 1, 1, 1)
                        ts = ts.expand(-1, 1, img0.shape[2], img0.shape[3])
                        outs = net(img0.expand(b, -1, -1, -1), img1.expand(b, -1, -1, -1), timestep=ts, cache={"img0": f0, "img1": f1})
                    for z in range(b):
                        result[mids[i + z][0]] = outs[z, :, :H, :W].to(out_dtype)
                    i += b
                except model_management.OOM_EXCEPTION:
                    if batch <= 1:
                        raise
                    batch = max(1, batch // 2)
                    model_management.soft_empty_cache()
            pbar.update(jj - j)
            j = jj
        frames = result.movedim(1, -1).clamp_(0.0, 1.0)
        strength = float(deflicker if deflicker_strength is None else deflicker_strength)
        if strength > 0:
            frames = calm_flicker(frames, strength)
        return (frames,)


# ── v3.35 · the depth MOTION RIG (the Portal Swapper's people route) ──
DEPTH_MODEL_DIR = "aip_depth/depth_anything_v2_small_hf"
MASK_DET_DIR = "aip_depth/rtdetr_v2_r18vd_hf"      # v3.35.1 — RT-DETR v2 r18 (Apache-2.0): where the people are
MASK_SEG_DIR = "aip_depth/sam2_1_hiera_tiny_hf"    # v3.35.1 — SAM 2.1 tiny (Apache-2.0): their exact silhouettes


def boxes_grow(boxes, H, W, frac=0.04):
    """v3.35.1 — detection boxes (xyxy) grown by frac of the frame's long side on every
    edge (hair, hands and a swinging coat lie outside a tight box), clamped to the frame."""
    g = float(frac) * max(int(H), int(W))
    out = []
    for b in boxes:
        x0, y0, x1, y1 = [float(v) for v in b]
        out.append([max(0.0, x0 - g), max(0.0, y0 - g), min(float(W), x1 + g), min(float(H), y1 + g)])
    return out


def hold_missing(masks, found):
    """v3.35.1 — masks (n, H, W); found[i] False = no person detected in frame i: that
    frame takes the previous detected frame's mask (the leading frames take the first
    detected one), so a detector miss never flashes the filmed person back for a frame."""
    n = int(masks.shape[0])
    last = None
    for i in range(n):
        if found[i]:
            last = i
        elif last is not None:
            masks[i] = masks[last]
    nxt = None
    for i in range(n - 1, -1, -1):
        if found[i]:
            nxt = i
        elif nxt is not None and not any(found[:i + 1]):
            masks[i] = masks[nxt]
    return masks


def mask_feather(masks, grow_frac=0.02, feather_px=3):
    """v3.35.1 — (n, H, W) masks 0..1 → grown by grow_frac of the frame height (a max
    filter: the silhouette covers the person fully, hair and all) and softened at the
    edge (a box blur of feather_px). The inside stays 1 — no filmed pixel of the person
    survives — and the edge melts into the room."""
    m = masks.float().unsqueeze(1)
    H = int(m.shape[-2])
    k = int(round(float(grow_frac) * H))
    if k > 0:   # pack v11 — max over the rectangle, one axis at a time (identical, O(k) instead of O(k²))
        m = torch.nn.functional.max_pool2d(m, kernel_size=(1, 2 * k + 1), stride=1, padding=(0, k))
        m = torch.nn.functional.max_pool2d(m, kernel_size=(2 * k + 1, 1), stride=1, padding=(k, 0))
    f = int(feather_px)
    if f > 0:   # pack v11 — the same box one axis at a time
        m = torch.nn.functional.avg_pool2d(m, kernel_size=(1, 2 * f + 1), stride=1, padding=(0, f), count_include_pad=False)
        m = torch.nn.functional.avg_pool2d(m, kernel_size=(2 * f + 1, 1), stride=1, padding=(f, 0), count_include_pad=False)
    return m[:, 0].clamp(0.0, 1.0)


def soften_depth(depth, frac):
    """v3.35.1 — (n, H, W) depth 0..1 blurred by a radius of frac × H (three box
    passes ≈ a Gaussian): the filmed person's hair edges, necklace, bow and dress
    outline melt away, the body pose, blocking and camera stay — Seedance keeps
    what a reference video SHOWS as geometry, and a motion rig must not show the look."""
    H = int(depth.shape[-2])
    r = int(round(float(frac) * H))
    if r <= 0:
        return depth
    x = depth.float().unsqueeze(1)
    k = 2 * r + 1
    for _ in range(3):   # pack v11 — the same box one axis at a time (a 2-D pass cost O(r²) per pixel on the CPU)
        x = torch.nn.functional.avg_pool2d(x, kernel_size=(1, k), stride=1, padding=(0, r), count_include_pad=False)
        x = torch.nn.functional.avg_pool2d(x, kernel_size=(k, 1), stride=1, padding=(r, 0), count_include_pad=False)
    return x[:, 0].clamp(0.0, 1.0).to(depth.dtype)


FACE_MODEL_DIR = "aip_depth/yunet"                    # v3.35.1 — YuNet (OpenCV zoo, Apache-2.0): where the faces are
FACE_MODEL_FILE = "face_detection_yunet_2023mar.onnx"


def face_boxes(frames_u8, model_path, score=0.6):
    """v3.35.1 — frames_u8: a list of (H, W, 3) RGB uint8 frames → per frame a list of
    [x0, y0, x1, y1] face boxes (YuNet through OpenCV's FaceDetectorYN). None when this
    OpenCV has no FaceDetectorYN (then: no face detail, the rig stays a plain blob)."""
    try:
        import cv2
        if not hasattr(cv2, "FaceDetectorYN"):
            return None
    except Exception:
        return None
    import numpy as np
    H, W = int(frames_u8[0].shape[0]), int(frames_u8[0].shape[1])
    det = cv2.FaceDetectorYN.create(str(model_path), "", (W, H), float(score), 0.3, 5000)
    out = []
    for f in frames_u8:
        _, faces = det.detect(np.ascontiguousarray(f[:, :, ::-1]))
        boxes = []
        if faces is not None:
            for r in faces:
                x, y, w, h = [float(v) for v in r[:4]]
                boxes.append([max(0.0, x), max(0.0, y), min(float(W), x + w), min(float(H), y + h)])
        out.append(boxes)
    return out


def face_region_mask(boxes_per_frame, H, W, grow=0.35, feather_frac=0.02):
    """v3.35.1 — per-frame face boxes → ((n, H, W) soft masks, found): each box grown by
    `grow` of its own size (more above it: the hair line), filled, feathered by
    feather_frac × H; a frame without a face takes the nearest frame's (hold_missing)."""
    n = len(boxes_per_frame)
    m = torch.zeros((n, int(H), int(W)), dtype=torch.float32)
    found = [False] * n
    for i, boxes in enumerate(boxes_per_frame):
        for x0, y0, x1, y1 in boxes or []:
            gw, gh = (x1 - x0) * float(grow), (y1 - y0) * float(grow)
            a, b = max(0, int(x0 - gw)), max(0, int(y0 - gh * 1.4))
            c, d = min(int(W), int(x1 + gw)), min(int(H), int(y1 + gh))
            if c > a and d > b:
                m[i, b:d, a:c] = 1.0
                found[i] = True
    if not any(found):
        return m, found
    m = hold_missing(m, found)
    return mask_feather(m, 0.0, int(round(float(feather_frac) * int(H)))), found


def composite_rig(frames, depth, masks):
    """v3.35.1 — frames (n, H, W, 3) 0..1, depth (n, H, W) 0..1 grey, masks (n, H, W) 0..1
    → the frame where the mask is 0, the depth grey where it is 1: the people become the
    rig, the room stays as filmed."""
    m = masks.to(frames.dtype).unsqueeze(-1)
    d = depth.to(frames.dtype).unsqueeze(-1).expand(-1, -1, -1, 3)
    return frames * (1.0 - m) + d * m


def person_masks(frames_u8, det_dir, seg_dir, device, threshold=0.2, grow=0.04, progress=None):
    """v3.35.1 — frames_u8: a list of (H, W, 3) uint8 numpy frames → (masks (n, H, W)
    float32 on the CPU, found [bool]). RT-DETR finds the people in each frame, SAM 2
    cuts each one out from its (grown) box, the cut-outs are unioned per frame. The
    detector threshold is LOW (0.2): a person cut by the frame (no head — a model's
    gown, a passer-by) scores ~0.3, and a missed person means filmed skin reaches
    Seedance; a false positive only turns a bit of the room grey. No ComfyUI
    dependency (testable on its own)."""
    from transformers import AutoImageProcessor, AutoModelForObjectDetection, Sam2Model, Sam2Processor
    det_p = AutoImageProcessor.from_pretrained(str(det_dir))
    det = AutoModelForObjectDetection.from_pretrained(str(det_dir)).to(device).eval()
    person_ids = {int(k) for k, v in det.config.id2label.items() if str(v).lower() == "person"} or {0}
    seg_p = Sam2Processor.from_pretrained(str(seg_dir))
    seg = Sam2Model.from_pretrained(str(seg_dir)).to(device).eval()
    n = len(frames_u8)
    H, W = int(frames_u8[0].shape[0]), int(frames_u8[0].shape[1])
    masks = torch.zeros((n, H, W), dtype=torch.float32)
    found = [False] * n
    B = 8
    with torch.no_grad():
        for i in range(0, n, B):
            chunk = list(frames_u8[i:i + B])
            inp = det_p(images=chunk, return_tensors="pt").to(device)
            out = det(**inp)
            res = det_p.post_process_object_detection(out, threshold=float(threshold), target_sizes=[(H, W)] * len(chunk))
            for j, r in enumerate(res):
                keep = [b.tolist() for b, l in zip(r["boxes"], r["labels"]) if int(l) in person_ids]
                keep = [b for b in keep if (b[2] - b[0]) * (b[3] - b[1]) >= 0.002 * H * W]
                if not keep:
                    continue
                boxes = boxes_grow(keep, H, W, grow)
                sin = seg_p(images=chunk[j], input_boxes=[boxes], return_tensors="pt").to(device)
                sout = seg(**sin, multimask_output=False)
                pm = seg_p.post_process_masks(sout.pred_masks.cpu(), sin["original_sizes"].cpu())[0]
                masks[i + j] = pm.reshape(-1, H, W).any(dim=0).float()
                found[i + j] = True
            if progress:
                progress(min(n, i + B))
    del det, seg
    return masks, found


# ── 2026-11-21 (pack v13) · Motion only for cars: the HERO vehicle masked instead of the people ──
VEHICLE_LABELS = ("car", "truck", "bus")   # COCO classes of RT-DETR v2 (id2label) that stand for a car-like vehicle


def box_iou(a, b):
    """IoU of two xyxy boxes (0 when they do not overlap)."""
    ix = max(0.0, min(a[2], b[2]) - max(a[0], b[0]))
    iy = max(0.0, min(a[3], b[3]) - max(a[1], b[1]))
    inter = ix * iy
    ua = (a[2] - a[0]) * (a[3] - a[1]) + (b[2] - b[0]) * (b[3] - b[1]) - inter
    return inter / ua if ua > 0 else 0.0


def _box_follows(prev, cand, iou_min=0.15):
    """does cand continue prev in the next frame? Enough overlap, or (a fast car) its centre within half
    of prev's diagonal at a similar size"""
    if box_iou(prev, cand) >= iou_min:
        return True
    pa = max(1e-6, (prev[2] - prev[0]) * (prev[3] - prev[1]))
    ca = (cand[2] - cand[0]) * (cand[3] - cand[1])
    pcx, pcy = (prev[0] + prev[2]) / 2.0, (prev[1] + prev[3]) / 2.0
    ccx, ccy = (cand[0] + cand[2]) / 2.0, (cand[1] + cand[3]) / 2.0
    diag = math.hypot(prev[2] - prev[0], prev[3] - prev[1])
    return math.hypot(ccx - pcx, ccy - pcy) <= 0.5 * diag and 0.4 <= ca / pa <= 2.5


def merge_boxes(boxes, iou=0.6):
    """one box per vehicle: the detector often reports one car twice (as "car" AND "truck" — a pickup, an SUV);
    boxes that overlap by IoU >= iou are one vehicle and the larger box is kept. Pure."""
    keep = []
    for b in sorted(boxes or [], key=lambda b: -(b[2] - b[0]) * (b[3] - b[1])):
        if all(box_iou(b, k) < float(iou) for k in keep):
            keep.append(list(b))
    return keep


VEHICLE_SIDES = ("main", "left", "right", "centre")   # which car of a shot: the main one, or the one the target names a side of


def _track_cx(t):
    """a track's centre x, weighted by its boxes' areas"""
    return sum(((b[0] + b[2]) / 2.0) * (b[2] - b[0]) * (b[3] - b[1]) for b in t["boxes"].values()) / max(1e-6, t["area"])


def hero_track(boxes_per_frame, max_gap=12, prefer="main", width=None, side_min=0.15):
    """boxes_per_frame: per frame a list of xyxy vehicle boxes → per frame the HERO vehicle's box or None.
    The detections are linked frame to frame into tracks (a box continues the track whose last box it
    follows, within max_gap frames); the hero is the track with the largest summed area — the car the shot
    is about, the most visible for the longest. Parked cars around it stay as filmed. prefer "left" /
    "right" / "centre" (the target said "the car on the left") picks, among the tracks with at least
    side_min of the main one's summed area, the one whose centre lies furthest that way (width = the
    frame's). Pure (no torch)."""
    tracks = []
    for i, boxes in enumerate(boxes_per_frame):
        used = set()
        for b in sorted(boxes or [], key=lambda b: -(b[2] - b[0]) * (b[3] - b[1])):
            best, best_iou = None, -1.0
            for t in tracks:
                if id(t) in used or i - t["last_i"] > max_gap or not _box_follows(t["last"], b):
                    continue
                v = box_iou(t["last"], b)
                if v > best_iou:
                    best, best_iou = t, v
            if best is None:
                best = {"boxes": {}, "area": 0.0}
                tracks.append(best)
            best["boxes"][i] = list(b)
            best["last"], best["last_i"] = list(b), i
            best["area"] += (b[2] - b[0]) * (b[3] - b[1])
            used.add(id(best))
    out = [None] * len(boxes_per_frame)
    if tracks:
        hero = max(tracks, key=lambda t: t["area"])
        if prefer in ("left", "right", "centre") and width:
            cands = [t for t in tracks if t["area"] >= float(side_min) * hero["area"]]
            if prefer == "left":
                hero = min(cands, key=_track_cx)
            elif prefer == "right":
                hero = max(cands, key=_track_cx)
            else:
                hero = min(cands, key=lambda t: abs(_track_cx(t) - float(width) / 2.0))
        for i, b in hero["boxes"].items():
            out[i] = b
    return out


def hero_gap_fill(hero, boxes_per_frame, iou_min=0.3):
    """a frame where the hero track has no box although the detector found vehicles takes the detection that
    overlaps the hero's last box (forward, then backward from the next one) by IoU >= iou_min: a track the
    linking broke (a duplicate box, a jump in size) keeps following the same car. Only a frame without any
    detection is left to hold_missing. Pure."""
    out = list(hero)
    n = len(out)
    for order in (range(n), range(n - 1, -1, -1)):
        ref = None
        for i in order:
            if out[i] is not None:
                ref = out[i]
            elif ref is not None and boxes_per_frame[i]:
                b = max(boxes_per_frame[i], key=lambda b: box_iou(b, ref))
                if box_iou(b, ref) >= float(iou_min):
                    out[i] = list(b)
                    ref = out[i]
    return out


def vehicle_hero(boxes_per_frame, prefer="main", width=None):
    """one shot's vehicle detections → per frame the hero car's box or None: duplicates merged, tracked, gaps filled"""
    merged = [merge_boxes(q) for q in boxes_per_frame]
    return hero_gap_fill(hero_track(merged, prefer=prefer, width=width), merged)


def hull_mask(mask):
    """(H, W) bool numpy → the filled convex hull of its pixels (bool numpy): the car's footprint without its
    exact outline (roofline, spoiler, mirrors, the gap under the body) — another body fits in it."""
    import numpy as np
    from PIL import Image, ImageDraw
    H, W = mask.shape
    rows = np.where(mask.any(axis=1))[0]
    if rows.size == 0:
        return mask
    left = np.argmax(mask[rows], axis=1)                       # the first and last set pixel of every row
    right = W - 1 - np.argmax(mask[rows][:, ::-1], axis=1)
    pts = sorted(set([(int(x), int(y)) for x, y in zip(left, rows)] + [(int(x), int(y)) for x, y in zip(right, rows)]))
    if len(pts) < 3:
        return mask

    def cross(o, a, b):
        return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0])
    lower, upper = [], []
    for p in pts:                       # Andrew's monotone chain
        while len(lower) >= 2 and cross(lower[-2], lower[-1], p) <= 0:
            lower.pop()
        lower.append(p)
    for p in reversed(pts):
        while len(upper) >= 2 and cross(upper[-2], upper[-1], p) <= 0:
            upper.pop()
        upper.append(p)
    poly = lower[:-1] + upper[:-1]
    if len(poly) < 3:
        return mask
    im = Image.new("L", (W, H), 0)
    ImageDraw.Draw(im).polygon(poly, fill=255, outline=255)
    return (np.asarray(im) > 127) | mask


def shot_spans(n, cuts=None):
    """n frames and the cut intervals (k = between frame k and k + 1, detect_cuts) → [(start, end)] per shot"""
    spans, s = [], 0
    for k in sorted(int(c) for c in (cuts or ()) if 0 <= int(c) < n - 1):
        spans.append((s, k + 1))
        s = k + 1
    spans.append((s, n))
    return [sp for sp in spans if sp[1] > sp[0]]


def vehicle_masks(frames_u8, det_dir, seg_dir, device, threshold=0.3, grow=0.015, progress=None, cuts=None, prefer="main"):
    """frames_u8: a list of (H, W, 3) uint8 numpy frames → (masks (n, H, W) uint8 0/1 on the CPU, found [bool]).
    RT-DETR finds the vehicles (car / truck / bus) in each frame, vehicle_hero picks THE car of each SHOT (an edit
    of several shots: the cuts split it; a vehicle reported twice is one; prefer: the target's side), SAM 2.1 cuts
    it out from its (slightly grown) box, the cut-out becomes its convex hull, a frame of the shot without any
    detection takes the nearest frame's mask (hold_missing within the shot). A shot where no car is found at all
    while others have one (a detail close-up the detector does not read as a car) becomes the rig as a whole —
    nothing of the old car carries over. No car in the whole clip: found is all False. No ComfyUI dependency."""
    import numpy as np
    from transformers import AutoImageProcessor, AutoModelForObjectDetection, Sam2Model, Sam2Processor
    det_p = AutoImageProcessor.from_pretrained(str(det_dir))
    det = AutoModelForObjectDetection.from_pretrained(str(det_dir)).to(device).eval()
    ids = {int(k) for k, v in det.config.id2label.items() if str(v).lower() in VEHICLE_LABELS} or {2, 5, 7}
    n = len(frames_u8)
    H, W = int(frames_u8[0].shape[0]), int(frames_u8[0].shape[1])
    per = []
    B = 8
    with torch.no_grad():
        for i in range(0, n, B):
            chunk = list(frames_u8[i:i + B])
            inp = det_p(images=chunk, return_tensors="pt").to(device)
            out = det(**inp)
            res = det_p.post_process_object_detection(out, threshold=float(threshold), target_sizes=[(H, W)] * len(chunk))
            for r in res:
                keep = [b.tolist() for b, l in zip(r["boxes"], r["labels"]) if int(l) in ids]
                per.append([b for b in keep if (b[2] - b[0]) * (b[3] - b[1]) >= 0.002 * H * W])
            if progress:
                progress(min(n, i + B) // 2)
    del det
    spans = shot_spans(n, cuts)
    hero = [None] * n
    for s0, s1 in spans:
        hero[s0:s1] = vehicle_hero(per[s0:s1], prefer=prefer, width=W)
    seg_p = Sam2Processor.from_pretrained(str(seg_dir))
    seg = Sam2Model.from_pretrained(str(seg_dir)).to(device).eval()
    masks = torch.zeros((n, H, W), dtype=torch.uint8)   # 0/1 — a long 1080p take: a quarter of float32's memory
    found = [False] * n
    with torch.no_grad():
        for i in range(n):
            b = hero[i]
            if b is not None:
                gb = boxes_grow([b], H, W, grow)[0]
                sin = seg_p(images=frames_u8[i], input_boxes=[[gb]], return_tensors="pt").to(device)
                sout = seg(**sin, multimask_output=False)
                pm = seg_p.post_process_masks(sout.pred_masks.cpu(), sin["original_sizes"].cpu())[0]
                m = pm.reshape(-1, H, W).any(dim=0).numpy()
                x0, y0, x1, y1 = [int(round(v)) for v in gb]
                bw, bh = x1 - x0, y1 - y0
                box = np.zeros((H, W), dtype=bool)   # the detector box is often a little tight (a bumper, a diffuser below it):
                box[max(0, y0 - bh // 4):min(H, y1 + 1 + bh // 4), max(0, x0 - bw // 4):min(W, x1 + 1 + bw // 4)] = True
                m = m & box                  # …but nothing far outside it (a reflection, a shadow far off)
                if m.sum() < 0.05 * max(1.0, bw * bh):
                    m = np.zeros((H, W), dtype=bool)
                    m[max(0, y0):min(H, y1 + 1), max(0, x0):min(W, x1 + 1)] = True   # SAM found next to nothing: the box stands in
                masks[i] = torch.from_numpy(hull_mask(m).astype(np.uint8))
                found[i] = True
            if progress and (i % 8 == 7 or i == n - 1):
                progress(n // 2 + (i + 1) // 2)
    del seg
    if any(found):
        for s0, s1 in spans:
            if any(found[s0:s1]):
                masks[s0:s1] = hold_missing(masks[s0:s1], found[s0:s1])
            else:
                masks[s0:s1] = 1
            found[s0:s1] = [True] * (s1 - s0)
    return masks, found


VEHICLE_CAR_SOFTEN = 5.0   # the car's own blur, relative to its size: soften × this × the car's height (Shape detail
                           # 50 % = 0.2 × the car's height), never less than soften × the frame height — the old body's
                           # profile (bonnet step, cab, roofline) melts the same in a 16:9 wide shot and a vertical close one


def grey_shots(masks, spans):
    """the shots that became the rig as a whole (every frame's mask is all 1: no car found there)"""
    return [(s0, s1) for s0, s1 in spans if int(masks[s0:s1].min()) >= 1]


def car_heights(masks, spans, win=4):
    """per frame the hero's height in px (its hull's rows), a running median over ±win frames of its shot (the
    blur does not flicker with SAM's outline); None for the frames of a shot that is the rig as a whole"""
    n = int(masks.shape[0])
    raw = [None] * n
    for j in range(n):
        rows = torch.nonzero(masks[j].amax(dim=1)).flatten()
        if rows.numel():
            raw[j] = int(rows[-1]) - int(rows[0]) + 1
    out = [None] * n
    grey = set(grey_shots(masks, spans))
    for s0, s1 in spans:
        if (s0, s1) in grey:
            continue
        for j in range(s0, s1):
            v = sorted(x for x in raw[max(s0, j - win):min(s1, j + win + 1)] if x is not None)
            out[j] = v[len(v) // 2] if v else None
    return out


def feather_px(m, k, f):
    """(h, w) 0/1 → grown by k px and softened by a box of f px — mask_feather's result for a 0/1 mask, in pixels
    (a crop of the frame gives the same result as the whole frame when it reaches k + 2f past the mask). The grow
    is a box SUM > 0 (the same as the max filter on 0/1, ~40x faster on the CPU than a wide max_pool2d)."""
    x = (m > 0).float()[None, None]
    if k > 0:
        t = 0.5 / (2 * k + 1)   # one set pixel in the window → 1 / (2k + 1); none → exactly 0
        x = (torch.nn.functional.avg_pool2d(x, kernel_size=(1, 2 * k + 1), stride=1, padding=(0, k), count_include_pad=False) > t).float()
        x = (torch.nn.functional.avg_pool2d(x, kernel_size=(2 * k + 1, 1), stride=1, padding=(k, 0), count_include_pad=False) > t).float()
    if f > 0:
        x = torch.nn.functional.avg_pool2d(x, kernel_size=(1, 2 * f + 1), stride=1, padding=(0, f), count_include_pad=False)
        x = torch.nn.functional.avg_pool2d(x, kernel_size=(2 * f + 1, 1), stride=1, padding=(f, 0), count_include_pad=False)
    return x[0, 0].clamp(0.0, 1.0)


def rig_region(m, k, f):
    """(H, W) 0/1 hull → (region, (y0, y1, x0, x1)): the grown + feathered rig region on the crop of the frame it can
    reach (outside the crop it is 0) — the same values as feather_px on the whole frame, a fraction of the work for a
    car that does not fill the frame. A frame that is all 1 is all 1."""
    H, W = int(m.shape[0]), int(m.shape[1])
    if int(m.min()) >= 1:
        return torch.ones((H, W), dtype=torch.float32), (0, H, 0, W)
    rows = torch.nonzero(m.amax(dim=1)).flatten()
    cols = torch.nonzero(m.amax(dim=0)).flatten()
    if not rows.numel():
        return torch.zeros((0, 0), dtype=torch.float32), (0, 0, 0, 0)
    p = int(k) + 2 * int(f) + 2
    y0, y1 = max(0, int(rows[0]) - p), min(H, int(rows[-1]) + 1 + p)
    x0, x1 = max(0, int(cols[0]) - p), min(W, int(cols[-1]) + 1 + p)
    return feather_px(m[y0:y1, x0:x1], int(k), int(f)), (y0, y1, x0, x1)


def car_depth(d, hull, radius_px, q=0.25, full=0.9):
    """d (h, w) the clip's depth at the inference size (one scale, near bright), hull (H, W) the hero's hull,
    radius_px the blur in FRAME pixels → (the car's soft depth at a small work size (1, 1, hs, ws), lo or None):
    the depth blurred (three box passes) at a work size where the radius is ~8 px — any radius costs the same —
    and lo, the q-quantile of the blurred depth inside the hull away from its blurred edge: inside the rig region
    nothing is farther than the car itself (the margin over the sky or the trees is lifted to it, no dark band
    traces the old roofline). A hull over more than `full` of the frame (a close-up) gets no lift (lo None)."""
    H = int(hull.shape[0])
    h = int(d.shape[-2])
    r_low = max(0.0, float(radius_px)) * h / float(H)
    s = max(1, int(r_low // 8))
    x = d.float()[None, None]
    if s > 1:
        x = torch.nn.functional.avg_pool2d(x, kernel_size=s, stride=s, ceil_mode=True, count_include_pad=False)
    r = int(round(r_low / s))
    if r > 0:
        x = soften_depth(x[0], r / float(x.shape[-2]))[None]
    hw = (int(x.shape[-2]), int(x.shape[-1]))
    inside = torch.nn.functional.interpolate(hull.float()[None, None], size=hw, mode="area")[0, 0] > 0.5
    lo = None
    if bool(inside.any()) and float(inside.float().mean()) <= float(full):
        e = r + 1   # the hull shrunk by the blur (a min filter, one axis at a time): the background is not mixed in there
        inv = (~inside).float()[None, None]
        inv = torch.nn.functional.max_pool2d(inv, kernel_size=(1, 2 * e + 1), stride=1, padding=(0, e))
        inv = torch.nn.functional.max_pool2d(inv, kernel_size=(2 * e + 1, 1), stride=1, padding=(e, 0))
        core = inv[0, 0] < 0.5
        vals = x[0, 0][core if bool(core.any()) else inside]
        lo = float(torch.quantile(vals, float(q)))
    return x, lo


def vehicle_keep_rig(images, depth, masks, spans, soften, grow, feather, out_dtype=torch.float32, progress=None, people=None):
    """Motion only + Keep the scene: images (n, H, W, 3) 0..1 the filmed frames, depth (n, h, w) the clip's depth at
    the inference size, masks (n, H, W) 0/1 the hero's hull per frame (held within each shot; a shot without a car
    is all 1), spans the shots → (n, H, W, 3) out_dtype: the filmed frame, with the car's soft depth grey laid into
    its grown + feathered hull. The car is blurred relative to its own height (car_heights × VEHICLE_CAR_SOFTEN ×
    soften, never less than soften × H); the edge margin (grow, feather) stays tied to soften × H, so the grey shape
    does not eat more of the filmed scene. Frame by frame, on the crop the rig reaches: no clip-sized temporaries.
    v14 — people (a dict for people_frame: masks, soften, face_detail, fmask) lays the people's rig over each frame
    (Recast with People AND Cars in the shot); None = the car alone, as before."""
    n, H, W = int(images.shape[0]), int(images.shape[1]), int(images.shape[2])
    fpx = int(feather) + int(round(float(soften) * H))
    k = max(int(round(float(grow) * H)), fpx + 1)   # grown at least as far as the feather: no filmed pixel of the car at the edge
    heights = car_heights(masks, spans)
    out = torch.empty((n, H, W, 3), dtype=out_dtype)
    for j in range(n):
        R = float(soften) * H
        if heights[j] is not None:
            R = max(R, VEHICLE_CAR_SOFTEN * float(soften) * heights[j])
        dw, lo = car_depth(depth[j], masks[j], R)
        region, (y0, y1, x0, x1) = rig_region(masks[j], k, fpx)
        out[j] = images[j].to(out_dtype)
        car = None
        if y1 > y0 and x1 > x0:
            df = torch.nn.functional.interpolate(dw, size=(H, W), mode="bilinear", align_corners=False)[0, 0, y0:y1, x0:x1]
            if lo is not None:
                df = df.clamp(min=lo)
            a = region.unsqueeze(-1)
            sub = images[j, y0:y1, x0:x1].float()
            out[j, y0:y1, x0:x1] = (sub * (1.0 - a) + df.unsqueeze(-1) * a).to(out_dtype)
            car = (region, (y0, y1, x0, x1), df)
        if people is not None:   # v14 — the people over the car rig (the nearer depth wins where both are)
            people_frame(out, j, depth[j], car, **people)
        if progress and (j % 8 == 7 or j == n - 1):
            progress(j + 1)
    return out


def people_depth_frame(yj, H, W, soften, face_detail=0.0, fm=None):
    """v14 — one frame of the people's rig grey at frame size, exactly AIPDepthRig's per-frame trace: yj (h, w) the
    clip's depth at the inference size brought to (H, W), blurred by soften × H, the face region fm (H, W) 0..1 only
    (1 − face_detail) as much. Pure (torch only)."""
    f = torch.nn.functional.interpolate(yj[None, None], size=(int(H), int(W)), mode="bilinear", align_corners=False)[0, 0]
    if float(soften) > 0:
        fs = soften_depth(f.unsqueeze(0), float(soften))[0]
        if fm is not None:
            fl = soften_depth(f.unsqueeze(0), float(soften) * (1.0 - float(face_detail)))[0]
            fm_ = fm.to(fs.dtype)
            f = fs * (1.0 - fm_) + fl * fm_
        else:
            f = fs
    return f


def people_frame(out, j, yj, car, masks, soften, face_detail=0.0, fmask=None):
    """v14 — Recast with People AND Cars in the shot, one frame: out (n, H, W, 3) the car rig (frame j changed in place),
    yj (h, w) its depth at the inference size, car None or (region, (y0, y1, x0, x1), df) the car rig's region on its
    crop and the car's soft grey there, masks (n, H, W) 0..1 the people's grown + feathered silhouettes, fmask (n, H, W)
    or None their face regions → the people's soft depth grey laid over the car rig with composite_rig's own
    arithmetic. Inside the car's region the people's grey is never farther than the car's (the nearer depth wins: a
    person in front of the car stays a person; the background a person's mask catches next to the old roofline does
    not draw that roofline back); across the region's feather that lift fades out with it (no hard edge). Where the
    car's region does not reach, every pixel equals the people's keep rig."""
    m = masks[j]
    if not bool((m > 0).any()):
        return
    H, W = int(out.shape[1]), int(out.shape[2])
    f = people_depth_frame(yj, H, W, soften, face_detail, None if fmask is None else fmask[j])
    if car is not None:
        region, (y0, y1, x0, x1), df = car
        sub = f[y0:y1, x0:x1]
        # review 2026-11-21: the lift fades with the region's own feather (a hard switch at region > 0 drew the
        # region's outline back as a crisp line where a person's mask runs past it); inside the car it is the max
        r = region.to(sub.dtype)
        f[y0:y1, x0:x1] = sub + r * (torch.maximum(sub, df.to(sub.dtype)) - sub)
    out[j:j + 1] = composite_rig(out[j:j + 1], f.to(out.dtype)[None], m[None]).to(out.dtype)


def depth_normalize(maps, near_bright=True, lo_q=0.02, hi_q=0.98):
    """(N, h, w) relative inverse depth (any scale) → (N, h, w) float32 in 0..1
    with ONE scale for the whole clip (no flicker between frames): the 2nd..98th
    percentile of a sample of the values. near_bright: a near surface is white
    (Depth Anything predicts inverse depth), else black."""
    x = maps.float()
    flat = x.flatten()
    if flat.numel() > 2_000_000:
        flat = flat[torch.randint(0, flat.numel(), (2_000_000,))]
    lo = torch.quantile(flat, float(lo_q))
    hi = torch.quantile(flat, float(hi_q))
    if not bool(hi > lo):
        hi = lo + 1e-6
    y = ((x - lo) / (hi - lo)).clamp_(0.0, 1.0)
    return y if near_bright else 1.0 - y


def depth_inference_size(H, W, size=518):
    """the inference size: the short side = `size` (a multiple of 14, DINOv2's
    patch), the aspect kept → (h, w)"""
    s = max(14, int(size) // 14 * 14)
    if H <= W:
        return s, max(14, int(round(W / float(H) * s / 14.0)) * 14)
    return max(14, int(round(H / float(W) * s / 14.0)) * 14), s


def depth_maps(images, model_dir, size=518, near_bright=True):
    """v3.35.1 (pack v9) — (n, H, W, 3) frames 0..1 → (n, h, w) float32 depth 0..1 at the
    inference size (one scale for the whole clip): Depth Anything V2 Small through
    transformers, batched, halving the batch on OOM. Shared by AIPDepthRig and AIPRigProbe."""
    import comfy.utils
    import folder_paths
    from comfy import model_management
    try:
        from transformers import AutoModelForDepthEstimation
    except Exception as e:
        raise RuntimeError("this ComfyUI has no `transformers` package — update ComfyUI") from e
    d = Path(folder_paths.models_dir) / model_dir
    if not (d / "config.json").is_file() or not (d / "model.safetensors").is_file():
        raise RuntimeError(f"the depth model is not downloaded yet ({d})")
    device = model_management.get_torch_device()
    dtype = torch.float16 if device.type == "cuda" else torch.float32
    model = AutoModelForDepthEstimation.from_pretrained(str(d)).to(device=device, dtype=dtype).eval()
    n, H, W = int(images.shape[0]), int(images.shape[1]), int(images.shape[2])
    h, w = depth_inference_size(H, W, int(size))
    mean = torch.tensor([0.485, 0.456, 0.406], device=device, dtype=dtype).view(1, 3, 1, 1)
    std = torch.tensor([0.229, 0.224, 0.225], device=device, dtype=dtype).view(1, 3, 1, 1)
    maps = torch.empty((n, h, w), dtype=torch.float16)
    pbar = comfy.utils.ProgressBar(n)
    batch, i = 4, 0
    with torch.no_grad():
        while i < n:
            b = min(batch, n - i)
            try:
                x = images[i:i + b].movedim(-1, 1).to(device=device, dtype=dtype)
                x = torch.nn.functional.interpolate(x, size=(h, w), mode="bilinear", align_corners=False)
                x = (x - mean) / std
                out = model(pixel_values=x).predicted_depth
                if out.dim() == 4:
                    out = out[:, 0]
                if tuple(out.shape[-2:]) != (h, w):
                    out = torch.nn.functional.interpolate(out.unsqueeze(1), size=(h, w), mode="bilinear", align_corners=False)[:, 0]
                maps[i:i + b] = out.to("cpu", torch.float16)
                i += b
                pbar.update(b)
            except model_management.OOM_EXCEPTION:
                if batch <= 1:
                    raise
                batch = max(1, batch // 2)
                model_management.soft_empty_cache()
    del model
    model_management.soft_empty_cache()
    return depth_normalize(maps, bool(near_bright))


def probe_picks(n, k):
    """v3.35.1 (pack v9) — k frame indices spread over n frames, away from the very ends (the
    first and last frames are often a fade or a cut): the centres of k equal slices."""
    n, k = int(n), max(1, int(k))
    if n <= k:
        return list(range(max(0, n)))
    return sorted({min(n - 1, max(0, int(round((i + 0.5) * n / k - 0.5)))) for i in range(k)})


def pack_probe(frames, depth, pmask, fmask, preview_h=360):
    """v3.35.1 (pack v9) — frames (k, H, W, 3) 0..1, depth / people mask / face region (k, H, W)
    0..1 → one (1, k·h, 2·w, 3) sheet at preview height h: per row the filmed frame on the
    left and the packed maps on the right (R = depth, G = people, B = face), the rows top to
    bottom. The app draws the rig at any softness from this without another GPU pass."""
    k, H, W = int(depth.shape[0]), int(depth.shape[1]), int(depth.shape[2])
    h = max(2, int(preview_h) // 2 * 2)
    w = max(2, int(round(W * h / float(H))) // 2 * 2)
    aa = (h < H)
    fr = torch.nn.functional.interpolate(frames.float().movedim(-1, 1), size=(h, w), mode="bilinear", align_corners=False, antialias=aa).movedim(1, -1)
    maps = torch.stack([depth.float(), pmask.float(), fmask.float()], dim=1)
    mp = torch.nn.functional.interpolate(maps, size=(h, w), mode="bilinear", align_corners=False, antialias=aa).movedim(1, -1)
    rows = torch.cat([fr, mp], dim=2)
    return rows.reshape(1, k * h, 2 * w, 3).clamp(0.0, 1.0)


class AIPDepthRig:
    @classmethod
    def INPUT_TYPES(cls):
        return {"required": {
            "images": ("IMAGE",),
            "model_dir": ("STRING", {"default": DEPTH_MODEL_DIR}),
            "size": ("INT", {"default": 518, "min": 126, "max": 1036, "step": 14}),
            "near_bright": ("BOOLEAN", {"default": True}),
        }, "optional": {
            # v3.35.1 — scene keep: only the people become the rig, the room stays as filmed
            "scene": (["rebuild", "keep"], {"default": "rebuild"}),
            "det_dir": ("STRING", {"default": MASK_DET_DIR}),
            "seg_dir": ("STRING", {"default": MASK_SEG_DIR}),
            "grow": ("FLOAT", {"default": 0.02, "min": 0.0, "max": 0.2, "step": 0.005}),
            "feather": ("INT", {"default": 3, "min": 0, "max": 30}),
            # v3.35.1 — a soft rig: the depth blurred by this fraction of the frame height
            # (the keep-mask feather widens by the same), so no hair cut, jewellery or
            # garment outline of the filmed person reaches Seedance as geometry
            "soften": ("FLOAT", {"default": 0.0, "min": 0.0, "max": 0.1, "step": 0.005}),
            # v3.35.1 — the face keeps its motion: its depth is blurred only (1 - face_detail) as much
            "face_detail": ("FLOAT", {"default": 0.0, "min": 0.0, "max": 1.0, "step": 0.05}),
            "face_dir": ("STRING", {"default": FACE_MODEL_DIR}),
            # v13 (2026-11-21) — scene keep masks the people (default) or THE car of the shot (Motion only)
            # v14 — or both: the car of each shot, then the people over it (Recast with both switches)
            "subject": (["person", "vehicle", "both"], {"default": "person"}),
            # v13 — which car of each shot (Motion only): the main one, or the one the target names a side of
            "prefer": (list(VEHICLE_SIDES), {"default": "main"}),
            # v14 — subject both: the car's own softness and grow (soften / grow are the people's there)
            "vehicle_soften": ("FLOAT", {"default": 0.04, "min": 0.0, "max": 0.1, "step": 0.005}),
            "vehicle_grow": ("FLOAT", {"default": 0.03, "min": 0.0, "max": 0.2, "step": 0.005}),
        }}

    RETURN_TYPES = ("IMAGE",)
    RETURN_NAMES = ("images",)
    FUNCTION = "run"
    CATEGORY = "AI Portal"
    DESCRIPTION = "A z-depth render of the frames (Depth Anything V2 Small, one scale for the clip): the motion rig the Portal Swapper sends instead of filmed people."

    def _vehicle_keep(self, images, y, det_dir, seg_dir, grow, feather, soften, prefer, out_dtype):
        """v13 — Motion only + Keep the scene: THE car of each shot becomes the rig (its hull, grown so far that the
        feather never shows a filmed pixel of it, its depth blurred relative to its own size), everything else stays
        as filmed. The ui output tells the app how many shots became the rig as a whole (no car found there)."""
        import comfy.utils
        import folder_paths
        from comfy import model_management
        n = int(images.shape[0])
        dd, sd = Path(folder_paths.models_dir) / det_dir, Path(folder_paths.models_dir) / seg_dir
        for d_, what in ((dd, "vehicle detector"), (sd, "vehicle mask model")):
            if not (d_ / "config.json").is_file() or not (d_ / "model.safetensors").is_file():
                raise RuntimeError(f"the {what} is not downloaded yet ({d_})")
        u8 = [(images[j].clamp(0, 1) * 255).round().to(torch.uint8).cpu().numpy() for j in range(n)]
        pbar = comfy.utils.ProgressBar(2 * n)
        cuts = detect_cuts(motion_weights(images))   # an edit of several shots: the car of each shot
        spans = shot_spans(n, cuts)
        masks, found = vehicle_masks(u8, dd, sd, model_management.get_torch_device(), progress=lambda k: pbar.update_absolute(k),
                                     cuts=cuts, prefer=(prefer if prefer in VEHICLE_SIDES else "main"))
        del u8
        model_management.soft_empty_cache()
        if not any(found):
            raise RuntimeError("no car found in the shot — Keep the scene needs the car in view; use Rebuild the scene")
        grey = len(grey_shots(masks, spans))
        frames = vehicle_keep_rig(images, y, masks, spans, soften, grow, feather, out_dtype, progress=lambda k: pbar.update_absolute(n + k))
        return {"ui": {"aip_rig": [{"subject": "vehicle", "shots": len(spans), "grey_shots": grey}]}, "result": (frames,)}

    def _both_keep(self, images, y, det_dir, seg_dir, grow, feather, soften, face_detail, face_dir, vehicle_grow, vehicle_soften, out_dtype):
        """v14 — Recast with People AND Cars in the shot, one prepared shot: the main car of each shot becomes the car rig
        exactly as in _vehicle_keep (its hull, the car's softness and grow), then the people's keep rig is laid over it
        (their silhouettes grown + feathered, their softness, the face rule; inside the car's region the nearer depth
        wins — people_frame) — a person in front of the car stays a person. Everything else stays as filmed. Either one
        not found: an error naming its switch."""
        import comfy.utils
        import folder_paths
        from comfy import model_management
        n, H = int(images.shape[0]), int(images.shape[1])
        dd, sd = Path(folder_paths.models_dir) / det_dir, Path(folder_paths.models_dir) / seg_dir
        for d_, what in ((dd, "detector"), (sd, "mask model")):
            if not (d_ / "config.json").is_file() or not (d_ / "model.safetensors").is_file():
                raise RuntimeError(f"the {what} is not downloaded yet ({d_})")
        device = model_management.get_torch_device()
        u8 = [(images[j].clamp(0, 1) * 255).round().to(torch.uint8).cpu().numpy() for j in range(n)]
        pbar = comfy.utils.ProgressBar(4 * n)
        cuts = detect_cuts(motion_weights(images))
        spans = shot_spans(n, cuts)
        vmasks, vfound = vehicle_masks(u8, dd, sd, device, progress=lambda k: pbar.update_absolute(k), cuts=cuts)
        if not any(vfound):
            raise RuntimeError("no car found in the shot — turn off Cars in the shot")
        pmasks, pfound = person_masks(u8, dd, sd, device, progress=lambda k: pbar.update_absolute(n + k))
        model_management.soft_empty_cache()
        if not any(pfound):
            raise RuntimeError("no person found in the shot — turn off People in the shot")
        fmask = None
        if float(soften) > 0 and float(face_detail) > 0:   # the people's face rule (as in run)
            fp = Path(folder_paths.models_dir) / face_dir / FACE_MODEL_FILE
            if fp.is_file():
                fb = face_boxes(u8, fp)
                if fb is not None:
                    fm_, ff_ = face_region_mask(fb, H, int(images.shape[2]))
                    fmask = fm_ if any(ff_) else None
        del u8
        grey = len(grey_shots(vmasks, spans))
        pm = mask_feather(hold_missing(pmasks, pfound), float(grow), int(feather) + int(round(float(soften) * H)))
        del pmasks
        pbar.update_absolute(3 * n)
        frames = vehicle_keep_rig(images, y, vmasks, spans, float(vehicle_soften), float(vehicle_grow), int(feather), out_dtype,
                                  progress=lambda k: pbar.update_absolute(3 * n + k),
                                  people={"masks": pm, "soften": float(soften), "face_detail": float(face_detail), "fmask": fmask})
        return {"ui": {"aip_rig": [{"subject": "both", "shots": len(spans), "grey_shots": grey}]}, "result": (frames,)}

    def run(self, images, model_dir, size, near_bright, scene="rebuild", det_dir=MASK_DET_DIR, seg_dir=MASK_SEG_DIR, grow=0.02, feather=3, soften=0.0,
            face_detail=0.0, face_dir=FACE_MODEL_DIR, subject="person", prefer="main", vehicle_soften=0.04, vehicle_grow=0.03):
        import comfy.utils
        import folder_paths
        from comfy import model_management
        n, H, W = int(images.shape[0]), int(images.shape[1]), int(images.shape[2])
        y = depth_maps(images, model_dir, int(size), bool(near_bright))   # v3.35.1 (pack v9) — shared with AIPRigProbe
        out_dtype = model_management.intermediate_dtype()
        if str(scene) == "keep" and str(subject) == "vehicle":   # v13 — Motion only for cars (no face pass, no full-size depth stack)
            return self._vehicle_keep(images, y, det_dir, seg_dir, float(grow), int(feather), float(soften), str(prefer), out_dtype)
        if str(scene) == "keep" and str(subject) == "both":   # v14 — Recast with People AND Cars in the shot
            return self._both_keep(images, y, det_dir, seg_dir, float(grow), int(feather), float(soften), float(face_detail), face_dir,
                                   float(vehicle_grow), float(vehicle_soften), out_dtype)
        # v3.35.1 — the faces: found once (YuNet) when the soft rig should keep their motion
        u8 = None
        fmask = None
        if float(soften) > 0 and float(face_detail) > 0:
            fp = Path(folder_paths.models_dir) / face_dir / FACE_MODEL_FILE
            if fp.is_file():
                u8 = [(images[j].clamp(0, 1) * 255).round().to(torch.uint8).cpu().numpy() for j in range(n)]
                fb = face_boxes(u8, fp)
                if fb is not None:
                    fm_, ff_ = face_region_mask(fb, H, W)
                    fmask = fm_ if any(ff_) else None
        frames = torch.empty((n, H, W, 3), dtype=out_dtype)
        for j in range(n):
            f = torch.nn.functional.interpolate(y[j:j + 1].unsqueeze(0), size=(H, W), mode="bilinear", align_corners=False)[0, 0]
            if float(soften) > 0:
                fs = soften_depth(f.unsqueeze(0), float(soften))[0]   # v3.35.1 — a soft rig
                if fmask is not None:
                    fl = soften_depth(f.unsqueeze(0), float(soften) * (1.0 - float(face_detail)))[0]
                    fm = fmask[j].to(fs.dtype)
                    f = fs * (1.0 - fm) + fl * fm
                else:
                    f = fs
            frames[j] = f.unsqueeze(-1).expand(H, W, 3).to(out_dtype)
        if str(scene) == "keep":
            # v3.35.1 — only the people become the rig: find them, cut them out, grow and
            # feather the silhouettes, lay the depth grey into them over the filmed frame
            dd, sd = Path(folder_paths.models_dir) / det_dir, Path(folder_paths.models_dir) / seg_dir
            for d_, what in ((dd, "people detector"), (sd, "people mask model")):
                if not (d_ / "config.json").is_file() or not (d_ / "model.safetensors").is_file():
                    raise RuntimeError(f"the {what} is not downloaded yet ({d_})")
            if u8 is None:
                u8 = [(images[j].clamp(0, 1) * 255).round().to(torch.uint8).cpu().numpy() for j in range(n)]
            pbar2 = comfy.utils.ProgressBar(n)
            masks, found = person_masks(u8, dd, sd, model_management.get_torch_device(), progress=lambda k: pbar2.update_absolute(k))   # v10 — the device is asked here (depth_maps keeps its own)
            model_management.soft_empty_cache()
            if not any(found):
                raise RuntimeError("no person found in the shot — Keep the scene masks people; use Rebuild the scene")
            masks = mask_feather(hold_missing(masks, found), float(grow), int(feather) + int(round(float(soften) * H)))   # v3.35.1 — a soft rig widens the feather
            frames = composite_rig(images.to(out_dtype).cpu(), frames[..., 0], masks).to(out_dtype)
        return (frames,)


class AIPRigProbe:
    """v3.35.1 (pack v9) — the Portal Swapper's DETAIL PREVIEW: a few frames of the shot traced
    once (depth, the people's silhouettes for scene keep, the face regions) and packed into one
    sheet (pack_probe), so the app can show the prepared shot at any Shape-detail setting
    without another GPU pass."""
    @classmethod
    def INPUT_TYPES(cls):
        return {"required": {
            "images": ("IMAGE",),
            "model_dir": ("STRING", {"default": DEPTH_MODEL_DIR}),
            "size": ("INT", {"default": 518, "min": 126, "max": 1036, "step": 14}),
            "near_bright": ("BOOLEAN", {"default": True}),
        }, "optional": {
            "scene": (["rebuild", "keep"], {"default": "rebuild"}),
            "det_dir": ("STRING", {"default": MASK_DET_DIR}),
            "seg_dir": ("STRING", {"default": MASK_SEG_DIR}),
            "face_dir": ("STRING", {"default": FACE_MODEL_DIR}),
            "picks": ("INT", {"default": 3, "min": 1, "max": 8}),
            "preview_h": ("INT", {"default": 360, "min": 90, "max": 1080, "step": 2}),
        }}

    RETURN_TYPES = ("IMAGE",)
    RETURN_NAMES = ("sheet",)
    FUNCTION = "run"
    CATEGORY = "AI Portal"
    DESCRIPTION = "A few frames of the clip traced once (depth, people, faces) into one packed sheet: the Portal Swapper's detail preview."

    def run(self, images, model_dir, size, near_bright, scene="rebuild", det_dir=MASK_DET_DIR, seg_dir=MASK_SEG_DIR, face_dir=FACE_MODEL_DIR,
            picks=3, preview_h=360):
        import folder_paths
        from comfy import model_management
        n = int(images.shape[0])
        idx = probe_picks(n, int(picks))
        sel = images[idx]
        k, H, W = int(sel.shape[0]), int(sel.shape[1]), int(sel.shape[2])
        y = depth_maps(sel, model_dir, int(size), bool(near_bright))
        depth = torch.nn.functional.interpolate(y.unsqueeze(1), size=(H, W), mode="bilinear", align_corners=False)[:, 0]
        u8 = [(sel[j].clamp(0, 1) * 255).round().to(torch.uint8).cpu().numpy() for j in range(k)]
        fmask = torch.zeros((k, H, W), dtype=torch.float32)
        fp = Path(folder_paths.models_dir) / face_dir / FACE_MODEL_FILE
        if fp.is_file():
            fb = face_boxes(u8, fp)
            if fb is not None:
                fm_, ff_ = face_region_mask(fb, H, W)
                if any(ff_):
                    fmask = fm_
        pmask = torch.zeros((k, H, W), dtype=torch.float32)
        if str(scene) == "keep":
            dd, sd = Path(folder_paths.models_dir) / det_dir, Path(folder_paths.models_dir) / seg_dir
            for d_, what in ((dd, "people detector"), (sd, "people mask model")):
                if not (d_ / "config.json").is_file() or not (d_ / "model.safetensors").is_file():
                    raise RuntimeError(f"the {what} is not downloaded yet ({d_})")
            masks, found = person_masks(u8, dd, sd, model_management.get_torch_device())
            model_management.soft_empty_cache()
            if any(found):
                pmask = hold_missing(masks, found)   # raw silhouettes: the app grows and feathers them per setting
        return (pack_probe(sel.float().cpu(), depth.float().cpu(), pmask, fmask, int(preview_h)),)


UPSCALE_TARGETS = {"1080p": (1920, 1080), "2k": (2560, 1440), "4k": (3840, 2160)}


def fit_target(H, W, target):
    """v3.35.1 — the output size for a size tier: the frame fitted inside the tier's box
    (3840×2160 for 4K, the box turned for a portrait frame), the aspect kept, both
    sides even, never smaller than the source. → (h, w)"""
    box = UPSCALE_TARGETS.get(str(target).lower(), UPSCALE_TARGETS["4k"])
    long_, short = max(box), min(box)
    bw, bh = (long_, short) if int(W) >= int(H) else (short, long_)
    sc = max(1.0, min(bw / float(W), bh / float(H)))
    return int(round(int(H) * sc / 2.0)) * 2, int(round(int(W) * sc / 2.0)) * 2


class AIPUpscaleVideo:
    @classmethod
    def INPUT_TYPES(cls):
        return {"required": {
            "images": ("IMAGE",),
            "upscale_model": ("UPSCALE_MODEL",),
            "fps": ("FLOAT", {"default": 24.0, "min": 1.0, "max": 240.0, "step": 0.001}),
            "target": (["1080p", "2k", "4k"], {"default": "4k"}),
            "deflicker": ("FLOAT", {"default": 0.3, "min": 0.0, "max": 1.0, "step": 0.05}),
            "filename_prefix": ("STRING", {"default": "aip_smooth/upscale"}),
            "crf": ("INT", {"default": 14, "min": 0, "max": 40}),
            "chunk": ("INT", {"default": 8, "min": 1, "max": 64}),
        }, "optional": {"audio": ("AUDIO",)}}

    RETURN_TYPES = ()
    FUNCTION = "run"
    OUTPUT_NODE = True
    CATEGORY = "AI Portal"
    DESCRIPTION = "The Fast local upscale: the upscale model on frame chunks (tiled), fitted to 1080p / 2K / 4K, the flicker calmed across chunk borders, written to an H.264 MP4 as it goes with the source audio."

    def run(self, images, upscale_model, fps, target, deflicker, filename_prefix, crf, chunk, audio=None):
        import comfy.utils
        import folder_paths
        from comfy import model_management
        n, H, W = int(images.shape[0]), int(images.shape[1]), int(images.shape[2])
        h, w = fit_target(H, W, target)
        full, fname, counter, sub, _ = folder_paths.get_save_image_path(
            filename_prefix, folder_paths.get_output_directory(), w, h)
        file = f"{fname}_{counter:05}_.mp4"
        device = model_management.get_torch_device()
        model_management.free_memory(model_management.module_size(upscale_model.model) + (512 * 512 * 3) * 4 * max(upscale_model.scale, 1.0) * 384.0, device)
        upscale_model.to(device)
        writer = Mp4Writer(os.path.join(full, file), w, h, float(fps), audio, int(crf))
        pbar = comfy.utils.ProgressBar(n)
        prev = None          # the previous chunk's last frame: the deflicker's context across the border
        tile, overlap = 512, 32
        step = max(1, int(chunk))
        try:
            for i in range(0, n, step):
                x = images[i:i + step].movedim(-1, 1).to(device)
                while True:
                    try:
                        y = comfy.utils.tiled_scale(x, lambda a: upscale_model(a.float()), tile_x=tile, tile_y=tile, overlap=overlap,
                                                    upscale_amount=upscale_model.scale, output_device=device)
                        break
                    except Exception as e:
                        model_management.raise_non_oom(e)
                        tile //= 2
                        if tile < 128:
                            raise
                y = torch.clamp(y, 0.0, 1.0)
                if tuple(y.shape[-2:]) != (h, w):
                    if int(y.shape[-2]) >= h:
                        y = torch.nn.functional.interpolate(y, size=(h, w), mode="area")
                    else:
                        y = torch.nn.functional.interpolate(y, size=(h, w), mode="bicubic", align_corners=False)
                y = y.movedim(1, -1).clamp(0.0, 1.0).to("cpu", torch.float32)
                if float(deflicker) > 0:
                    batch = y if prev is None else torch.cat([prev, y], dim=0)
                    batch = calm_flicker(batch, float(deflicker))
                    y = batch[1:] if prev is not None else batch
                prev = y[-1:].clone()
                writer.add(y)
                pbar.update(int(y.shape[0]))
                del x, y
        finally:
            upscale_model.to("cpu")
            model_management.soft_empty_cache()
        writer.close()
        return {"ui": {"images": [{"filename": file, "subfolder": sub, "type": "output"}], "animated": (True,)}}


class AIPSaveVideo:
    @classmethod
    def INPUT_TYPES(cls):
        return {"required": {
            "images": ("IMAGE",),
            "fps": ("FLOAT", {"default": 60.0, "min": 1.0, "max": 240.0, "step": 0.001}),
            "filename_prefix": ("STRING", {"default": "aip_smooth/smooth"}),
            "crf": ("INT", {"default": 16, "min": 0, "max": 40}),
        }, "optional": {"audio": ("AUDIO",)}}

    RETURN_TYPES = ()
    FUNCTION = "save"
    OUTPUT_NODE = True
    CATEGORY = "AI Portal"
    DESCRIPTION = "Writes the frames as an H.264 MP4 at the given CRF (16 = visually lossless) with the audio."

    def save(self, images, fps, filename_prefix, crf, audio=None):
        import folder_paths
        full, fname, counter, sub, _ = folder_paths.get_save_image_path(
            filename_prefix, folder_paths.get_output_directory(), int(images.shape[2]), int(images.shape[1]))
        file = f"{fname}_{counter:05}_.mp4"
        write_mp4(os.path.join(full, file), images, float(fps), audio, int(crf))
        return {"ui": {"images": [{"filename": file, "subfolder": sub, "type": "output"}], "animated": (True,)}}


NODE_CLASS_MAPPINGS = {"AIPSmoothRetime": AIPSmoothRetime, "AIPSaveVideo": AIPSaveVideo, "AIPDepthRig": AIPDepthRig,
                       "AIPUpscaleVideo": AIPUpscaleVideo, "AIPRigProbe": AIPRigProbe}
NODE_DISPLAY_NAME_MAPPINGS = {"AIPSmoothRetime": "AI Portal · Smooth motion (retime + interpolate)",
                              "AIPSaveVideo": "AI Portal · Save video (H.264, CRF)",
                              "AIPDepthRig": "AI Portal · Depth motion rig",
                              "AIPUpscaleVideo": "AI Portal · Upscale video (fast, streamed)",
                              "AIPRigProbe": "AI Portal · Rig detail preview (trace)"}
